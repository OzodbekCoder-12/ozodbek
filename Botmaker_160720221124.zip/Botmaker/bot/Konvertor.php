<?php 

ob_start();

define('API_KEY','**TOKEN**');
##------------------------------##
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>";
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
 function sendmessage($chat_id, $text, $model){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>$mode
 ]);
 }
 function sendphoto($chat_id, $photo, $captionl){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
 function sendaudio($chat_id, $audio, $caption, $title ,$performer){
 bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>$audio,
 'caption'=>$caption,
 'title'=>$title,
 'performer'=>$performer
 ]);
 }
 function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
 function sendsticker($chat_id, $sticker){
 bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>$sticker
 ]);
 }
 function sendvideo($chat_id, $video, $caption){
 bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>$video,
 'caption'=>$caption
 ]);
 }
function sendvideonote($chat_id, $video_note, $caption){
 bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>$video_note,
 'caption'=>$caption
 ]);
 }
 function sendvoice($chat_id, $voice, $caption){
 bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>$voice,
 'caption'=>$caption
 ]);
 }

 function sendaction($chat_id, $action){
 bot('sendchataction',[
 'chat_id'=>$chat_id,
 'action'=>$caption
 ]);
 }
 function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
//====================Tikapp======================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->userame;
$text = $message->text;

//qoshimcha
$guruhlar = file_get_contents("stat/group.list");
$userlar = file_get_contents("stat/user.list");
$chat_id2 = $update->callback_query->message->chat->id;
$update = json_decode(file_get_contents('php://input'));
$message_id2 = $update->callback_query->message->message_id;
$ufname = $update->message->from->first_name;
$uname = $update->message->from->last_name;
$ulogin = $update->message->from->username;
$user_id = $update->message->from->id;
mkdir("stat");

$us = bot('getChatMembersCount',[
'chat_id'=>$cid
]);
$count = $us->result;



$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->callback_query->message->message_id;
$reply = $update->message->reply_to_message;
$mroan = file_get_contents("mroan.txt");
$ADMIN = "**ADMIN**";
//====================Tikapp======================//
if(preg_match('/^\/([Ss]tart)/',$text)){
$user = file_get_contents('Member.txt');
    $members = explode("\n",$user);
    if (!in_array($chat_id,$members)){
      $add_user = file_get_contents('Member.txt');
      $add_user .= $chat_id."\n";
     file_put_contents('Member.txt',$add_user);
    }
sendaction($chat_id, typing);
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'disable_web_page_preview'=>true,
                'text' =>"*Salom* [$ufname $uname](tg://user?id=$user_id) 🎓

♻️*Converter Botimizga Xush Kelibsiz 

Botimizning Vazifalari👇

📸Rasmni Conver Qiladi Yani (jpg) Farmatdegi Faylni (png) Farmatga Ko'chirib beradi
Va (png) Farmatni (jpg) Farmatga Aylantirib Beradi
Va Rasmni 🎊Stiker Qilib Xam Beradi

🎤Qo'shiqni 🎧Golos - 🎧Golosni esa 🎤Qo'shiq Qilib Beradi

🎥Videoni Esa Ovozini Uzini 🎶mp3 Farmatida Tashlab beradi Va Vidyo Tashlasez Uni Gif Ko'rinishida Tashledi*
",
                'parse_mode'=>"Markdown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔂 Boshlash 🌠",'callback_data'=>"a"]
              ],
              
[['text'=>'📊Statistika', 'callback_data' => "stat1"],['text'=>'🤖 Botlarimiz', 'callback_data'=> "botlarimiz"]]



              
              ]
        ])
            ]);
        }
        
  elseif($data == "orqa"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
 'disable_web_page_preview'=>true,
  'message_id'=>$message_id,
 'text'=>"Salom [$ufname $uname](tg://user?id=$user_id) 🎓

♻️*Converter Botimizga Xush Kelibsiz 

Botimizning Vazifalari👇

📸Rasmni Conver Qiladi Yani (jpg) Farmatdegi Faylni (png) Farmatga Ko'chirib beradi
Va (png) Farmatni (jpg) Farmatga Aylantirib Beradi
Va Rasmni 🎊Stiker Qilib Xam Beradi

🎤Qo'shiqni 🎧Golos - 🎧Golosni esa 🎤Qo'shiq Qilib Beradi

🎥Videoni Esa Ovozini Uzini 🎶mp3 Farmatida Tashlab beradi Va Vidyo Tashlasez Uni Gif Ko'rinishida Tashledi*",
 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔂 Boshlash 🌠",'callback_data'=>"a"]
              ],
            [['text'=>'📊Statistika', 'callback_data' => "stat1"],['text'=>'🤖 Botlarimiz', 'callback_data'=> "botlarimiz"]]




              ]
        ])
            ]);
        }      
        
//====================Tikapp======================//
 
elseif($data == "a"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
 'disable_web_page_preview'=>true,
  'message_id'=>$message_id,
 'text'=>"🎐┇_Conver Bo'limi _🔁
 
🔰*Conver Qilmoqchi Bolgan Narsezi Tanlen*👇
 
 - [Kanalimiz 📡](t.me/PHP_OWN)",
 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"🌌 RASM 🌠",'callback_data'=>"c"],['text'=>"🎥 Video 🎞",'callback_data'=>"d"]],
              [['text'=>"♪ Music-Golos 🎵",'callback_data'=>"e"]],
          [['text'=>"🔙 Orqaga",'callback_data'=>"orqa"]]
              ]
        ])
 ]);
}
elseif($data == "back"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"🎐┇_Conver Bo'limi_🔁
 
🔰*Conver Qilmoqchi Bo'lgan Narsezi Tanlen*👇
 
 - [Kanalimiz 📡](t.me/Qirmirvoy)",
 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [['text'=>"🌌 RASM 🌠",'callback_data'=>"c"],['text'=>"🎥 VIDEO 🎞",'callback_data'=>"d"]],
              [['text'=>"♪ Music-Golos🎤",'callback_data'=>"e"]],
              [['text'=>"🔙 Orqaga",'callback_data'=>"orqa"]]
              ]
        ])
 ]);
}
//====================Photo======================//
elseif($data == "c"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"🌋 *Rasmni Qaysi Farmatga Ko'chirmoqchisiz 
 
 Munyuni Tanlen*",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              
            [['text'=>" Rasmdan 🔜 PNGga💾",'callback_data'=>"c1"],['text'=>"󸐠 Rasmdan 🔜Stikerga 🔆",'callback_data'=>"c4"]],
[['text'=>"PNGdan 🔜 Rasmga💾",'callback_data'=>"c2"],['text'=>'☀️ Stickerdan ➡️ Rasmga 🖼','callback_data'=>"c3"]],
[['text'=>"Stickerdan 🔜 PNGga💾",'callback_data'=>"c5"],['text'=>'💾PNGdan ➡️ Stickerga ☀','callback_data'=>"c3"]],[['text'=>"Text To Sticker",'callback_data'=>"hj"]],
          [['text'=>"🔙 Orqaga",'callback_data'=>"back"]]
              ]
        ])
 ]);
}

elseif($data == "c1"){
file_put_contents("mroan.txt","c1");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"*JPG Farmatdegi Rasm Yuboring 💽 Sizga PNG Farmatda Tashlab Beraman📦*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($data == "c2"){
file_put_contents("mroan.txt","c2");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"*PNG Farmatdegi Rasm Yuboring Uni Sizga JPG Farmatda Tashlab Beraman 🌌*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($data == "c3"){
file_put_contents("mroan.txt","c3");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"*Rasmga aylantirish uchun Stickerni yuboring*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($data == "c4"){
file_put_contents("mroan.txt","c4");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"*Biror Bir Rasm Yuboring 🃏Uni Sizga Stiker Ko'rinishida Yuboraman💘*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($data == "c5"){
file_put_contents("mroan.txt","c5");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"• *Biror Bir Sticker Yuboring 🃏Uni Sizga PNG Ko'rinishida Yuboraman💘*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($data == "c6"){
file_put_contents("mroan.txt","c6");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"•Biror Bir PNG Yuboring 🃏Uni Sizga Stiker Ko'rinishida Yuboraman💘*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"c"]
              ]
              ]
        ])
 ]);
}
elseif($mroan == "c1"){
file_put_contents("mroan.txt","No");
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('Mroanmohmmed.png'),
 ]);
}
elseif($mroan == "c2"){
file_put_contents("mroan.txt","No");
$document = $message->document;
$file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
elseif($mroan == "c3"){
file_put_contents("mroan.txt","No");
$sticker = $message->sticker;
$file = $sticker->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
elseif($mroan == "c4"){
file_put_contents("mroan.txt","No");
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('Mroanmohmmed.png'),
 ]);
}
elseif($mroan == "c5"){
file_put_contents("mroan.txt","No");
$sticker = $message->sticker;
$file = $sticker->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
 elseif($mroan == "c6"){
 file_put_contents("mroan.txt","No");
$document = $message->document;
$file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
//====================video======================//
elseif($data == "d"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>" 🎥Videoni Taxrirlash Uchun Bo'lim
 
 - 🔰*Kereli Bo'limni Tanlen*",
 'parse_mode'=>"MarkDown",
       'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>"🎤Videoni Ovozini  Qirqish",'callback_data'=>"d1"],['text'=>"🎥Videoni Gif Qilish🎨 ",'callback_data'=>"d2"]],
            
              [['text'=>'📹Videodan➡️ PNGga 💾','callback_data'=>"d3"],['text'=>'📽Videodan ➡️ Yumoloq videoga 📀','callback_data'=>"d4"]],


              [['text'=>"🔙 Orqaga",'callback_data'=>"back"]]
              ]
        ])
 ]);
}

elseif($data == "d1"){
file_put_contents("mroan.txt","d1");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "• 🎤*Bu Bo'limga Siz 🎥Video Tashlasez 🎥Video Ovozini Qirqib🎶Mp3 Farmatida Tashlab Beradi*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"d"]
              ]
              ]
        ])
 ]);
}
elseif($data == "d2"){
file_put_contents("mroan.txt","d2");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>" •🔰*Bu Bo'limga Siz 🎥Video Tashlasez Sizga Uni 🎨Gif Ko'rinishida Tashlab Beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"d"]
              ]
              ]
        ])
 ]);
}
elseif($data == "d3"){
file_put_contents("mroan.txt","d3");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"• 🔰*Bu Bo'limga Siz 🎥Video Tashlasez Sizga Uni 💾PNG Ko'rinishida Tashlab Beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"d"]
              ]
              ]
        ])
 ]);
}
elseif($data == "d4"){
file_put_contents("mroan.txt","d4");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"• 🔰*Bu Bo'limga Siz 🎥Video Tashlasez Sizga Uni 📀Yumoloq video Ko'rinishida Tashlab Beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"d"]
              ]
              ]
        ])
 ]);
}

elseif($mroan == "d1"){
 file_put_contents("mroan.txt","No");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.mp3',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>new CURLFile('Mroanmohmmed.mp3'),
 ]);
 }
 elseif($mroan == "d2"){
 file_put_contents("mroan.txt","No");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.gif',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('Mroanmohmmed.gif'),
 ]);
 }
  elseif($mroan == "d3"){
 file_put_contents("mroan.txt","No");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.png',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
 elseif($mroan == "d4"){
 file_put_contents("mroan.txt","No");
$video = $message->video;
$file = $video->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.mp4',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendVideoNote',[
 'chat_id'=>$chat_id,
 'video_note'=>new CURLFile('Mroanmohmmed.mp4'),
 ]);
 }

//====================audio======================//
elseif($data == "e"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"🎤*Bu Bo'limda Siz Golosni-Mp3 Farmatga Mp3-Golosga Aylantirishiz Mumkin
 
 -🔰Bo'limni Tanlen*",
 'parse_mode'=>"MarkDown",
       'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>"🎧Golos-Mp3 🎤",'callback_data'=>"e1"],['text'=>"🎤Mp3-Golos🎧",'callback_data'=>"e2"]],
              [['text'=>'MP3 ➡️ VideoXabar','callback_data'=>"e3"],['text'=>'Zapis ➡️ VideoXabar','callback_data'=>"e4"]],
              [['text'=>"🔙 Orqaga",'callback_data'=>"back"]]
              ]
        ])
 ]);
}

elseif($data == "e1"){
file_put_contents("mroan.txt","e1");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "•🎧*Biror Bir Golos Tashlasez Uni Sizga Mp3 🎤Farmatda Tashlab beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"e"]
              ]
              ]
        ])
 ]);
}
elseif($data == "e2"){
file_put_contents("mroan.txt","e2");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "•Biror Bir 🎤Mp3 Tashlen Uni Sizga 🎧Golos Farmatida Tashlab Beraman",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"e"]
              ]
              ]
        ])
 ]);
}
elseif($data == "e3"){
file_put_contents("mroan.txt","e3");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"• 🔰*Bu Bo'limga Siz 🎵Mp3 Tashlasez Sizga Uni 📽Videoxabar Ko'rinishida Tashlab Beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"e"]
              ]
              ]
        ])
 ]);
}
 elseif($data == "e4"){
file_put_contents("mroan.txt","e4");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"• 🔰*Bu Bo'limga Siz 🎙Golos Tashlasez Sizga Uni 📽Video xabar Ko'rinishida Tashlab Beraman*",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"e"]
              ]
              ]
        ])
 ]);
}
elseif($mroan == "e1"){
 file_put_contents("mroan.txt","No");
$voice = $message->voice;
$file = $voice->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.mp3',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>new CURLFile('Mroanmohmmed.mp3'),
 ]);
 }
elseif($mroan == "e2"){
 file_put_contents("mroan.txt","No");
$audio = $message->audio;
$file = $audio->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.ogg',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile('Mroanmohmmed.ogg'),
 ]);
 }
 elseif($mroan == "e3"){
 file_put_contents("mroan.txt","No");
$audio = $message->audio;
$file = $audio->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.ogg',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendVideo',[
 'chat_id'=>$chat_id,
 'video'=>new CURLFile('Mroanmohmmed.mp4'),
 ]);
 }
 elseif($mroan == "e4"){
 file_put_contents("mroan.txt","No");
$voice = $message->voice;
$file = $voice->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      file_put_contents('Mroanmohmmed.ogg',file_get_contents('https://api.telegram.org/file/bot'.$API_KEY.'/'.$patch));
bot('sendVideo',[
 'chat_id'=>$chat_id,
 'video'=>new CURLFile('Mroanmohmmed.mp4'),
 ]);
 }
//====================text======================//
elseif($data == "g"){
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"🔱Bu bo'lim orqali textni golos qilishingiz mumkun📄
 
 Bo'limni tanlang 🔰",
 'parse_mode'=>"MarkDown",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                        [ ['text'=>"Textni Golosga 🎤",'callback_data'=>"g3"]
            ],
              [
              ['text'=>"🔙Orqaga",'callback_data'=>"back"]
              ]
              ]
        ])
 ]);
}
elseif($data == ""){
bot('sendmessage',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"- اختر ماتريد 🔰",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                        [
            ['text'=>" تحويل النص لملصق 🌇",'callback_data'=>"g1"],['text'=>"تحويل النص لصورة 🖼",'callback_data'=>"g2"]
            ],            
            [
            ['text'=>"تحويل النص لموسيقى 🎤",'callback_data'=>"g3"]
            ],
              [
              ['text'=>"العودة ◀️",'callback_data'=>"back"]
              ]
              ]
        ])
 ]);
}
elseif($data == "g1"){
file_put_contents("mroan.txt","g1");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "• حسنا عزيزي 🕯 ارسل النص ليتم تحويله لملصق 🔀",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>" العودة ◀️",'callback_data'=>"back5"]
              ]
              ]
        ])
 ]);
}
elseif($data == "g2"){
file_put_contents("mroan.txt","g2");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "• حسنا عزيزي ارسل النص ليتم تحويله ↩ لصورة 🏞",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>" العودة ◀️",'callback_data'=>"back5"]
              ]
              ]
        ])
 ]);
}
elseif($data == "g3"){
file_put_contents("mroan.txt","g3");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"•Biror bir soz yuboring biz sizga golos qilib beramiz",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"Orqaga🔙",'callback_data'=>"g"]
              ]
              ]
        ])
 ]);
}
elseif($mroan == "g1"){
 file_put_contents("mroan.txt","No");
	$photo = file_get_contents('http://tikapp.000webhostapp.com/ml/?color=white&text='.urlencode($text));
	file_put_contents('Mroanmohmmed.png',$photo);
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
elseif($mroan == "g2"){
 file_put_contents("mroan.txt","No");
	$photo = file_get_contents('http://tikapp.000webhostapp.com/ml/?color=white&text='.urlencode($text));
	file_put_contents('Mroanmohmmed.png',$photo);
bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('Mroanmohmmed.png'),
 ]);
 }
elseif($mroan == "g3"){
 file_put_contents("mroan.txt","No");
	$vo = file_get_contents('http://tts.baidu.com/text2audio?lan=en&ie=UTF-8&text='.urlencode($text));
 file_put_contents('vo.ogg',$vo);
 bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile('vo.ogg'),
 ]);
 }
elseif($data == "hj"){
file_put_contents("ali.txt","hj");
bot('editmessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=> "Stickerga aylantirish uchun Text yuboring",
 'parse_mode'=>"MarkDown",
      'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"Back◀️",'callback_data'=>"back"]
              ]
              ]
        ])
 ]);
}
elseif($mroan == "hj"){
 file_put_contents("mroan.txt","none");
$photo = file_get_contents('http://www.iloveheartstudio.com/-/p.php?t='.urlencode($text).'&bc=FFCBDB&tc=000000&hc=ff0000&f=c&uc=true&ts=true&ff=PNG&w=500&ps=sq');
file_put_contents('logo.png',$photo);
bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>new CURLFile('logo.png'),
 ]);
unlink('logo.png');
 }
//====================Tikapp======================//
if($data=="stat1"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "📊Siz Statistika bo'limidasiz",
      'show_alert'=>true
        ]);
$gr = substr_count($guruhlar,"\n"); 
$us = substr_count($userlar,"\n"); 
$obsh = $gr + $us;
 $soat = date('H:i', strtotime('5 hour'));
$bugun = date('d-M Y',strtotime('5 hour'));
   bot('editMessageText',[
   'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
       'text'=> "📊<b>Bot foydalanuvchilari:</b>
    
🌎 <b>Hammasi:</b> <b>$obsh</b>
├👤: <b>$us</b>
└👥: <b>$gr</b>

👤 - <b>Foydalanuvchilar</b>
👥 - <b>Guruhlar</b>

<b>📆 $bugun ⏰ $soat</b>",
'parse_mode' => 'html',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(
['inline_keyboard' => [
  [['text'=>'♻Yangilash', 'callback_data' => "statistika"]],
  [['text'=>'🔙Orqaga', 'callback_data' => "orqa"]]
]
]),
]);
}

if($data=="statistika"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "🌎 Hammasi: $obsh
├👤: $us
└👥: $gr

👤 - Foydalanuvchilar
👥 - Guruhlar
📆 $bugun ⏰ $soat",
      'show_alert'=>true
        ]);
}
 if($data=="malumot"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "📋Siz ma'lumot bo'limidasiz",
      'show_alert'=>true
        ]);
   bot('editMessageText',[
   'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=> "📃*Botning barcha imkoniyatlarini bilish uchun qo'llanmani o'qib chiqing qo'llanma pastda*",
'parse_mode' => 'markdown',
'disable_web_page_preview'=>true,
  'reply_markup'=>json_encode([   
   'inline_keyboard'=>[   
[['text'=>'📋Qollanma','url'=>'https://telegra.ph/Konverter-robot-05-16-2'],],
[['text'=>'🔙Orqaga qaytish','callback_data'=>"orqa"]]
]
]),
]);
}


     



if($data=="men"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "👨‍💻Siz Admin bo'limidasiz",
      'show_alert'=>true
        ]);
   bot('editMessageText',[
   'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=> "👮*Bot admini va reklama bo'yicha:* [[**ADMINISMI**]](https://t.me/[**ADMINUSER**])
🔰*Yangiliklar:* [Kanal](https://t.me/PHP_OWN)

⏳ *Ish Vaqti:* 13:00 - 23:00\n\n
*Bot yasattirish uchun* [🛠Yaratuvchi](https://t.me/[**ADMINUSER**]) *bilan narxlarni kelishib oling*",
    'parse_mode' => 'markdown',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'👨‍💻 Admin','url'=>'https://telegram.me/[**ADMINUSER**]'],], 
[['text'=>'🔙Orqaga', 'callback_data' => "orqa"]],
]
]),
]);
}
    
    
if($data=="\rimiz"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "♻Siz botlarimiz bo'limidasiz",
      'show_alert'=>true
        ]);
   bot('editMessageText',[
   'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=> "*Salom, biz yaratgan botlarimiz bilan tanishib chiqing. Sizlarga ham botlar kerak bo‘lsa, bizga murojaat qiling!*\n*Creator:* [@Hacker_oken]",
'parse_mode' => 'markdown',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>'🔮Inson Ongi', 'url'=>'https://t.me/onashka_bot'],], 
[['text'=>'🌐 YouTube', 'url'=>'https://t.me/youtubeuzb_bot'],], 
[['text'=>'❌Spamdan Chiqish', 'url'=>'https://t.me/spam_yoqbot'],], 
[['text'=>'✍Niklar', 'url'=>'https://t.me/super_nikbot'],], 
[['text'=>'✍Niklar 2', 'url'=>'https://t.me/niklardodasi_bot'],], 
[['text'=>'♻Converter', 'url'=>'https://t.me/conveter_bot'],], 
[['text'=>'⏰ Soat ', 'url'=>'https://t.me/soatuz_robot'],], 
[['text'=>'🖼Logotif', 'url'=>'https://t.me/logouz_robot'],], 
[['text'=>'💲Pul ishlash', 'url'=>'https://t.me/uzbsumbot'],], 
[['text'=>'🌤Ob-havo', 'url'=>'https://t.me/ob_havouz_robot'],], 
    [['text'=>'👨‍💻 Admin', 'callback_data'=> "a"],['text'=>'🔙 Orqaga', 'callback_data'=> "orqa"]],
]
]),
]);
}


   ?>