<?php
ob_start();

define('API_KEY','[*BOTTOKEN*]');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{return json_decode($res);}}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$chat_id = $message->chat->id;
$name = $message->from->first_name;
$chsaied = "Qitmirvoy"; //Sizning kanal identifikatoringiz @ ;
$SAEEDFiles = "[*ADMIN*]"; //Sizning qo'llaringiz

$id = $message->from->id;
$SA3ED = explode("\n",file_get_contents("SAEED.txt"));
$SAEED = count($SA3ED)-1;
$T4TTTT = file_get_contents("T4TTTT.txt");
if ($update && !in_array($chat_id, $SA3ED)) {
    file_put_contents("SAEED.txt", $chat_id."\n",FILE_APPEND);
  }
  //kod @Abroriy tomonidan tarjima qilindi va @PHP_OWN jamoasi tomonidan tarqatildi
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$chsaied&user_id=".$id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$chat_id,
 'text'=>"`Botdan foydalanish uchun botga obuna bo'lishingiz kerak ⚡️`
   📡 -: [@$chsaied]",
'parse_mode'=>"MarkDown",
]);return false;}
//kod @Abroriy tomonidan tarjima qilindi va @PHP_OWN jamoasi tomonidan tarqatildi
if ($text == '/start') {
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🖐 Salom <a href='tg://user?id=$id'>$name</a> Hush Kelibsiz!
☝️ Bu bot orqali siz 22 xil usulda nik yasashingiz mumkin!
🤘 Ismingizni yuboring
🎩 Bot Admini: <a href='tg://user?id=[**ADMIN**]'>[**ADMINISMI**]</a>",
'disable_web_page_preview'=>'true',
'parse_mode'=>'html',
'reply_markup'=>json_encode([
                'inline_keyboard'=>[
[['text'=>'Yaratuvchi','url'=>"https://t.me/goPHPbot"]],
]])
]);}
if($text != "/start" and $text  != "Posted" and $text != "Abonentlar" and $T4TTTT != "SAEED"){
$SAEED = file_get_contents("http://saeedfiles.tk/API.php?SAEEDFiles=".urlencode($text));
bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"$SAEED",
  'disable_web_page_preview'=>'true',
  'parse_mode'=>"MarkDown"
]);
}
if($text == "Abonentlar" and $id == $SAEEDFiles){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"❖|add abonentlari bot Tuzuvchi Ser {$SAEED} keng tarqalgan; 👥"
    ]);
}
//kod @Abroriy tomonidan tarjima qilindi va @PHP_OWN jamoasi tomonidan tarqatildi
if($text == "Posted" and $id == $SAEEDFiles){
 file_put_contents("T4TTTT.txt", "SAEED");
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"Xabarni master ishlab chiquvchiga yuboring va $ {$SAEED} ga umumiy tarzda yuboriladi; 📬"
    ]);
}
if($text != "Posted" and $text  != "/start" and $text != "Abonentlar" and $T4TTTT == "SAEED" and $id == $SAEEDFiles){
  for ($i=0; $i < count($SA3ED); $i++) { 
    bot('sendMessage',[
      'chat_id'=>$SA3ED[$i],
      'text'=>$text,
    ]);
  }
  unlink("T4TTTT.txt");
}
$tx = $message->text;
$catid = $message->chat->id;
$cturi = $message->chat->type;
if($tx and ($cturi == "private")) {
bot('sendmessage',[
    'chat_id'=>$catid,
    'text'=>"💡 Bot Yaratishni Hohlaysizmi?
🤖 @GoPHPbot ga tashrif buyuring,
📡 Kanalimiz: @PHP_OWN",
    ]);
}
//kod @Abroriy tomonidan tarjima qilindi va @PHP_OWN jamoasi tomonidan tarqatildi