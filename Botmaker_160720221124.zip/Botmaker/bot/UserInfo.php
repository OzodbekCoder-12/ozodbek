<?php
/*
Coderlaruz
*/
ob_start();
define('API_KEY','**TOKEN**'); /// Token
//======================
function Coderlaruz($method,$datas=[]){$url = "https://api.telegram.org/bot".API_KEY."/".$method;$ch = curl_init();curl_setopt($ch,CURLOPT_URL,$url);curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);$res = curl_exec($ch);if(curl_error($ch)){var_dump(curl_error($ch));}else{return json_decode($res);}}
function objectToArrays($object){if (!is_object($object) && !is_array($object)) {return $object;}if (is_object($object)) {$object = get_object_vars($object);}return array_map("objectToArrays", $object);}
function sendphoto($chat_id, $photo, $caption){Coderlaruz('sendphoto',['chat_id'=>$chat_id,'photo'=>$photo,'caption'=>$caption,]);}
function Forward($KojaShe,$AzKoja,$KodomMSG){Coderlaruz('ForwardMessage',['chat_id'=>$KojaShe,'from_chat_id'=>$AzKoja,'message_id'=>$KodomMSG]);}
function save($filename,$TXTdata){$myfile = fopen($filename, "w") or die("Unable to open file!");fwrite($myfile, "$TXTdata");fclose($myfile);}
function sendmessage($ChatId, $TextMsg){Coderlaruz('sendmessage',['chat_id'=>$chatid,'text'=>$TextMsg,'parse_mode'=>"MarkDown"]);}
/*
//======================
www.muzclub.uz
//======================
*/
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
$textmessage = isset($update->message->text)?$update->message->text:'';
$username = $update->message->from->username;
$messageid = $update->message->message_id;
$from_id = $update->message->from->id;
$chat_id = $update->message->chat->id;
$chatid = $update->callback_query->message->chat->id;
$admin = "**ADMIN**";   //////////  idingiz
$profilim = "https://telegram.me/$username";
$name = $update->message->from->first_name;
$data = $update->callback_query->data;
$text = $update->message->text;
$message_id = $update->callback_query->message->message_id;
$message_id_feed = $update->message->message_id;
$fromid = $update->callback_query->from->id;
$Wcan = json_decode(file_get_contents("http://api.wecan-co.in/info/?peer=@$username"));
$bio = objectToArrays($Wcan);
$Bio = $bio['description'];
$step = file_get_contents("data/".$from_id."/step.txt");
mkdir("data");
mkdir("data/$from_id");
//==============================
if(preg_match('/^\/([Ss]tart)/',$text)){
Coderlaruz('sendphoto',[
    'chat_id'=>$chat_id,
 'photo'=>$profilim,
     'caption'=>"<b>Salom oshna Tepadagi profilingiz surati</b> \n\n😋<b>Profilingiz Haqida</b> \n\n<b>Ismingiz hamda profilingiz useringiz haqida malumoy</b>👇",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>'👉Sizning ismingiz☪️','callback_data'=>'a'],['text'=>"$name",'callback_data'=>'b']],
[['text'=>'👉Id raqamingiz🆔','callback_data'=>'c'],['text'=>"$chat_id",'callback_data'=>'e']],
[['text'=>'👉Useringiz💟','callback_data'=>'f'],['text'=>"$username",'callback_data'=>'g']],
[['text'=>'👉Biongiz👣','callback_data'=>'v'],['text'=>"$Bio",'callback_data'=>'q']],
[['text' => 'Shaxsiyingiz⚜', 'url' => "https://telegram.me/$username"]],
[['text'=>'💰Pul Ishlash','callback_data'=>'p'],['text'=>"🙋‍♂️Malumot",'callback_data'=>'men']],
],
])
]);
}
elseif(preg_match('/^\/([Pp]anel)/',$text) and $from_id == $admin){
Coderlaruz('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Panle bolimiga xush kelipsiz',
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'Statistika📊','callback_data'=>'azisaf'],['text'=>'Xabar Yuborish📪','callback_data'=>'send']],
],
])
]);
}

elseif($data == "p") {
Coderlaruz('sendmessage',[
    'chat_id'=>$chatid,
    'text'=>"<b><b>Pul Ishlash Bulimiga hush kelipsiz\n\n1) Telegram pul ishlash botlari \n2) Yangi pul ishlash saytlari \n3) Barchasi Ishonchli 100%</b>\n\n<b>Bush Joyda Siz Reklama Qoydiring!!\n\n\n
👨‍💼Admin uchun: /panel",
    'parse_mode'=>'html',
    
    ]);
}
    
elseif($data == "p") {
Coderlaruz('sendmessage',[
    'chat_id'=>$chatid,
    'text'=>"<b>Pul Ishlash Bulimiga hush kelipsiz\n\n1) Telegram pul ishlash botlari \n2) Yangi pul ishlash saytlari \n3) Barchasi Ishonchli 100%</b>\n\n<b>Bush Joyda Siz Reklama Qoydiring!!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔥 Kunlik 15000 ming', 'url'=>'https://t.me/Tegmo_bot?start=115056828']], 
],
])
]);
}

elseif($data == "men") {
Coderlaruz('sendmessage',[
    'chat_id'=>$chatid,
    'text'=>"<b>🙋‍♂️Bot Haqida Malumot</b>\n\n<b>⚙️Bu Bot orqali nimalar qilsa boladu :</b>\n\n<b>💰Internet va botlardan pul ishlash:</b>\n\n<b>ℹ️️Uzingiz Haqida Malumot Olishingiz:</b>\n\n<b>🔣Yana bazi bolinmalar bor:</b>
",
    'parse_mode'=>'html',
'reply_markup'=>json_encode([
      'keyboard'=>[
   [['text'=>"/start"]],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($data == "azisaf" && $chatid == $admin){
    $user = file_get_contents("members.txt");
    $member_id = explode("\n",$user);
    $odam_soni = count($member_id) -1;
    Coderlaruz('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "odamsoni : $odam_soni",

            'show_alert' => true
        ]);
    }
$user = file_get_contents('members.txt');
    $members = explode("\n",$user);
    if (!in_array($chat_id,$members)){
      $add_user = file_get_contents('members.txt');
      $add_user .= $chat_id."\n";
     file_put_contents('members.txt',$add_user);
    }
elseif($data == "send" && $fromid == $admin){
    file_put_contents("data/$from_id/step.txt","send");
 Coderlaruz('sendmessage',[
    'chat_id'=>$chatid,
    'text'=>"Xabaringizni yuboring!",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
   [['text'=>"/panel"]],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($step == "send" && $from_id == $admin){
    file_put_contents("data/$from_id/step.txt","none");
 Coderlaruz('sendmessage',[
    'chat_id'=>$chatid,
    'text'=>"😊Habaringiz Yuborilmadi",
'reply_markup'=>json_encode([
'remove_keyboard'=>true
])
  ]);
$all_member = fopen( "members.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
   Forward($user,$from_id,$messageid);
  }
}