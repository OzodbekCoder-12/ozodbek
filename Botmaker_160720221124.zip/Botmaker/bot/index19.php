<?php

ob_start();
define('API_KEY','**TOKEN**');
//Muoliflik xuquqi @HacKeR_OkeN ga tegishli
//muoliflik xuquqiga teginmang
function jijibot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//-------------------------------------------- HacKeR_OkeN---------------------------------------------

// msg
$Dev = "**ADMIN**";
$channel = "PHP_OWN";
$token = API_KEY;
//-----------------------------------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$textmassage = $message->text;
$firstname = $update->callback_query->from->first_name;
$usernames = $update->callback_query->from->username;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$membercall = $update->callback_query->id;
//-----------------------------------------HacKeR_OkeN-------------------------------
$forward_from_chat = $update->message->forward_from_chat;
$from_chat_id = $forward_from_chat->id;
$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$gpname = $update->callback_query->message->chat->title;
$namegroup = $update->message->chat->title;
//--------------------------------------------HacKeR_OkeN----------------------------
$newchatmemberid = $update->message->new_chat_member->id;
$newchatmemberu = $update->message->new_chat_member->username;
$rt = $update->message->reply_to_message;
$replyid = $update->message->reply_to_message->message_id;
$tedadmsg = $update->message->message_id;
$edit = $update->edited_message->text;
$re_id = $update->message->reply_to_message->from->id;
$re_user = $update->message->reply_to_message->from->username;
$user_id = $update->message->from->id;
$re_name = $update->message->reply_to_message->from->first_name;
$re_msgid = $update->message->reply_to_message->message_id;
$re_chatid = $update->message->reply_to_message->chat->id;
$re_fwdid = $update->message->reply_to_message->forward_from->id;
$message_edit_id = $update->edited_message->message_id;
$chat_edit_id = $update->edited_message->chat->id;
$edit_for_id = $update->edited_message->message->from->id;
$forward_from = $update->message->forward_from;
$forward_from_id = $forward_from->id;
$forward_from_username = $forward_from->username;
$reply = $update->message->reply_to_message->forward_from->id;
$reply_username = $update->message->reply_to_message->forward_from->username;
$reply_first = $update->message->reply_to_message->forward_from->first_name;
// =======================HacKeR_OkeN=================================================
$stat = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chat_id&user_id=".$from_id);
$statjson = json_decode($stat, true);
$status = $statjson['result']['status'];
$statq = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chatid&user_id=".$fromid);
$statjsonq = json_decode($statq, true);
$statusq = $statjsonq['result']['status'];
$get = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chat_edit_id&user_id=".$edit_for_id);
$info = json_decode($get, true);
$you = $info['result']['status'];
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$from_id));
$tch = $forchannel->result->status;
$forchannelq = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$fromid));
$tchq = $forchannelq->result->status;
//-------------------------------------------------HacKeR_OkeN----------------------------------------
mkdir("data/$from_id");
@$select = file_get_contents("data/$from_id/select.txt");
@$chat = file_get_contents("data/$from_id/chat.txt");
@$user = file_get_contents('Member.txt');
@$member = file_get_contents('data/chat.txt');
@$nashnas = file_get_contents("data/$from_id/nashnas.txt");
@$nashnas2 = file_get_contents("data/$fromid/nashnas.txt");
@$jenstyat = file_get_contents("data/$from_id/jenstyat.txt");
@$age = file_get_contents("data/$from_id/age.txt");
@$city = file_get_contents("data/$from_id/city.txt");
@$adds = file_get_contents("data/$from_id/member.txt");
@$adds2 = file_get_contents("data/$fromid/member.txt");
@$numchat = file_get_contents("data/$from_id/numchat.txt");
@$step = file_get_contents("data/$from_id/file.txt");
@$vip = file_get_contents("data/$from_id/vip.txt");
@$editinfo = file_get_contents("data/$from_id/edit.txt");
@$name = file_get_contents("data/$from_id/name.txt");
@$blocklist = file_get_contents('data/blocklist.txt');
@$like = file_get_contents("data/$from_id/like.txt");
@$deslike = file_get_contents("data/$from_id/deslike.txt");
@$blacklist = file_get_contents("data/$from_id/blacklist.txt");
@$frinds = file_get_contents("data/$from_id/frinds.txt");
//=======================HacKeR_OkeN==========================================================================

function SendMessage($chat_id, $text){
jijibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
 function senddocument($chat_id, $document, $caption){
 jijibot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
function sendAction($chat_id, $action){
jijibot('sendChataction',[
'chat_id'=>$chat_id,
'action'=>$action]);
}
function sendphoto($chat_id, $photo, $caption){
jijibot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption,
 ]);
 }
function sendsticker($chat_id, $sticker){
 jijibot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>$sticker
 ]);
 }
function LeaveChat($chat_id){
jijibot('LeaveChat',[
'chat_id'=>$chat_id
]);
}
function sendvoice($chat_id, $voice, $caption){
jijibot('sendvoice',[
'chat_id'=>$chat_id,
'voice'=>$voice,
'caption'=>$caption
]);
}
 function sendvideo($chat_id, $video, $caption){
 jijibot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>$video,
 'caption'=>$caption
 ]);
 }
 function Forward($berekoja,$azchejaei,$kodompayam)
{
jijibot('ForwardMessage',[
'chat_id'=>$berekoja,
'from_chat_id'=>$azchejaei,
'message_id'=>$kodompayam
]);
}
function  getUserProfilePhotos($token,$from_id) {
  $url = 'https://api.telegram.org/bot'.$token.'/getUserProfilePhotos?user_id='.$from_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->result;
  return $result;
}
function getChatMembersCount($chat_id,$token) {
  $url = 'https://api.telegram.org/bot'.$token.'/getChatMembersCount?chat_id='.$chat_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->result;
  return $result;
}
function SendContact($chatid,$first_name,$phone_number,$keyboard){
	jijibot('SendContact',[
	'chat_id'=>$chatid,
	'first_name'=>$first_name,
	'phone_number'=>$phone_number,
	'reply_markup'=>$keyboard
	]);
	}
//============================HacKeR_OkeN=======================================
    $members = explode("\n",$user);
    if (!in_array($from_id,$members)){
     $add_user = file_get_contents('Member.txt');
     $add_user .= $chat_id."\n";
     file_put_contents('Member.txt',$add_user);
    }
//==========================HacKeR_OkeN========================================
if(strpos($blocklist, "$from_id") !== false  ) {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz qoidalarga rioya qilmagani uchun robot tomonidan bloklangansiz

✥ Agar siz xabarni qayta yubormasangiz, ",
'reply_markup'=>json_encode(['KeyboardRemove'=>[
],'remove_keyboard'=>true
])
    		]);
}
if ( strpos($textmassage , '/start ') !== false  ) {
$start = str_replace("/start ","",$textmassage);
if($start == $from_id ) {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz allaqachon ✔  robotga taklif qilingansiz",
    		]);
}
else 
{
if ($start > 0){
file_put_contents("data/$from_id/numchat.txt","10");
file_put_contents("data/$from_id/member.txt","0");
file_put_contents("data/$from_id/like.txt","0");
file_put_contents("data/$from_id/deslike.txt","0");
$adds1 = file_get_contents("data/$start/member.txt");
$newmember = $adds1 +1;
file_put_contents("data/$start/member.txt","$newmember");
$adds2 = file_get_contents("data/$start/member.txt");
	jijibot('sendmessage',[
	'chat_id'=>$start,
	'text'=>"Bir foydalanuvchi sizning ✔  taklifnoma bilan botga kirdi
Siz taklif qilgan odamlarning soni: $adds2",
    		]);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Salom $first_name

Noma'lum robot chat robotiga xush kelibsiz

Ushbu robot bilan siz boshqalar bilan maxfiy ravishda suhbatlashishingiz mumkin

O'zingizning jinsingizni tanlang",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"👩‍🎓Ayol"],['text'=>"👨‍🎓Erkak"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/name.txt","$first_name");
}
else
{
$id = base64_decode($start);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 Agar tizimga kirgan shaxsni tasdiqlasangiz, suhbat haqida so'rov boshqa tomonga yuboriladiد",
    		]);
jijibot('sendmessage',[
	'chat_id'=>$id,
	'text'=>"📍 $name nomli kimsa:

📌 Talablar siz bilan suhbatlashadi

Quyidagi tugmalarni 🔻 »dan foydalaning»",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✅Qabul qilish"],['text'=>"❌Rad etish"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/chat.txt","chatnashnas");
file_put_contents("data/$id/chat.txt","chatnashnas");
file_put_contents("data/$id/nashnas.txt","$from_id");
file_put_contents("data/$from_id/nashnas.txt","$id");
}
}
}
if($textmassage=="/start" && $tc == "private"){	
if (strpos($user, "$from_id")!== false) {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
file_put_contents("data/$from_id/numchat.txt","4");
file_put_contents("data/$from_id/member.txt","0");
file_put_contents("data/$from_id/like.txt","0");
file_put_contents("data/$from_id/deslike.txt","0");
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Salom $first_name

Noma'lum robot chat robotiga xush kelibsiz

Ushbu robot bilan siz boshqalar bilan maxfiy ravishda suhbatlashishingiz mumkin

O'zingizning jinsingizni tanlang",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"👩‍🎓Ayol"],['text'=>"👨‍🎓Erkak"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/name.txt","$first_name");
}
}
elseif($textmassage=="👩‍🎓Ayol" && $tc == "private"){
file_put_contents("data/$from_id/jenstyat.txt","ayol");
file_put_contents("data/$from_id/select.txt","age");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Sizning jinsingiz muvaffaqiyatli saqlandi ✔️

Yoshingizni tanlang, ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"13"],['text'=>"14"],['text'=>"15"],['text'=>"16"]
				],
								[
				['text'=>"17"],['text'=>"18"],['text'=>"19"],['text'=>"20"]
				],
								[
				['text'=>"21"],['text'=>"22"],['text'=>"23"],['text'=>"24"]
				],
								[
				['text'=>"25"],['text'=>"26"],['text'=>"27"],['text'=>"28"]
				],
								[
				['text'=>"29"],['text'=>"30"],['text'=>"31"],['text'=>"32"]
				],
								[
				['text'=>"32 +"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($textmassage=="👨‍🎓Erkak" && $tc == "private"){
file_put_contents("data/$from_id/jenstyat.txt","erkak");
file_put_contents("data/$from_id/select.txt","age");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Sizning jinsingiz muvaffaqiyatli saqlandi ✔️

Yoshingizni tanlang, ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"13"],['text'=>"14"],['text'=>"15"],['text'=>"16"]
				],
								[
				['text'=>"17"],['text'=>"18"],['text'=>"19"],['text'=>"20"]
				],
								[
				['text'=>"21"],['text'=>"22"],['text'=>"23"],['text'=>"24"]
				],
								[
				['text'=>"25"],['text'=>"26"],['text'=>"27"],['text'=>"28"]
				],
								[
				['text'=>"29"],['text'=>"30"],['text'=>"31"],['text'=>"32"]
				],
								[
				['text'=>"32 +"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($select == "age" && $tc == "private"){
if ($textmassage <= 50 && $textmassage >= 14){
file_put_contents("data/$from_id/age.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","city");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Yoshingiz muvaffaqiyatli saqlandi ✔️

 Viloyatingizni tanlang 🔻 ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Toshkent"],['text'=>"Buxoro"],['text'=>"Navoi"]
				],
								[
				['text'=>"Xorazm"],['text'=>"Nukus"],['text'=>"Andijon"]
				],
								[
				['text'=>"Fargona"],['text'=>"Jizzax"],['text'=>"Qashqadaryo"]
				],
								[
				['text'=>"Surxondaryo"],['text'=>"Guliston"],['text'=>"Xiva"]
				],
								[
				['text'=>"Samarqand"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
if($select == "city" && $tc == "private"){
file_put_contents("data/$from_id/city.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","none");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Viloyat muvaffaqiyatli saqlandi ✔️

Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
elseif($textmassage=="💬Anonim suhbat" && $tc == "private"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Anonim chat bo'limiga xush kelibsiz

Iltimos, quyidagi xususiyatlardan birida anonim suhbatni boshlang: ✔️ ",
   'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text' => "Hech qanday farq yo'q"], ['text' => "bir xil yosh"]
],
[
['text' => "👨‍🎓 bola"], ['text' => "👩‍🎓 qiz"]
],
[
['text' => "📍Bir joydan bilan chat [yopish]"]
],
[
['text' => "🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
				jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Hurmatli foydalanuvchi siz robot kanalida emassiz va siz anonim suhbatdan foydalana olmaysiz ⚠️

⭕️ Quyidagi kanalga obuna bo'lish:

🆔 @$channel

Keyin robotga qayting va  qayta urinib ko'ring ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📡Chat kanali",'url'=>"https://t.me/$channel"]
	],
              ]
        ])
    		]);	
}
}
elseif($textmassage=="Hech qanday farq yo'q" && $tc == "private"){
if ($vip == "") {
if ($numchat > 0){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz muvaffaqiyatli ro'yxatga kiritdingiz ✔️

 Foydalanuvchini qidirishda, suhbatni boshlashni kuting ... ",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatda haqorat qilmang yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing. ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
			]);
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
file_put_contents("data/$from_id/chat.txt","dont");
}
else 
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Suhbatingiz vaqti tugagan 😞

Iltimos, robotingizni yangilashga harakat qiling ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);

}
}
}
if($textmassage=="Hech qanday farq yo'q" && $tc == "private"){
if ($vip != "") {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz muvaffaqiyatli ro'yxatga kiritdingiz ✔️

 Foydalanuvchini qidirishda, suhbatni boshlashni kuting ... ",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatda haqorat qilmang yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing. ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
			]);
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
file_put_contents("data/$from_id/chat.txt","dont");
}
}
if($textmassage == "✅Qabul qilish") {
$getuserprofile = getUserProfilePhotos($token,$nashnas);
$cuphoto = $getuserprofile->total_count;
$getuserphoto = $getuserprofile->photos[0][0]->file_id;
$getuserprofile2 = getUserProfilePhotos($token,$from_id);
$cuphoto2 = $getuserprofile2->total_count;
$getuserphoto2 = $getuserprofile2->photos[0][0]->file_id;
$like = file_get_contents("data/$nashnas/like.txt");
$deslike = file_get_contents("data/$nashnas/deslike.txt");
$like2 = file_get_contents("data/$from_id/like.txt");
$deslike2 = file_get_contents("data/$from_id/deslike.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
  jijibot('sendphoto',[
  'chat_id'=>$chat_id,
'photo'=>$getuserphoto,
  'caption'=>"❤  Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like)👍",'callback_data'=>"like"],['text'=>"($deslike)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"🤖 tizim xabari:

Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			  jijibot('sendphoto',[
  'chat_id'=>$nashnas,
'photo'=>$getuserphoto2,
  'caption'=>"❤  Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like2)👍",'callback_data'=>"like"],['text'=>"($deslike2)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
}
$memberex = explode("\n",$member);
$howmember = count($memberex) - 1;
$randmember = $memberex[mt_rand(0,$howmember)];
if($chat == "dont" && $tc == "private"){
if($textmassage == "Chatni boshlang") {
if ($randmember != "" && $randmember != $from_id){
file_put_contents("data/$from_id/chat.txt","chatnashnas");
file_put_contents("data/$randmember/chat.txt","chatnashnas");
file_put_contents("data/$randmember/nashnas.txt","$from_id");
file_put_contents("data/$from_id/nashnas.txt","$randmember");
$aval = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$dovom = str_replace("$randmember\n","",$member);
file_put_contents("data/chat.txt","$now");
$getuserprofile = getUserProfilePhotos($token,$randmember);
$cuphoto = $getuserprofile->total_count;
$getuserphoto = $getuserprofile->photos[0][0]->file_id;
$getuserprofile2 = getUserProfilePhotos($token,$from_id);
$cuphoto2 = $getuserprofile2->total_count;
$getuserphoto2 = $getuserprofile2->photos[0][0]->file_id;
$like = file_get_contents("data/$randmember/like.txt");
$deslike = file_get_contents("data/$randmember/deslike.txt");
$like2 = file_get_contents("data/$from_id/like.txt");
$deslike2 = file_get_contents("data/$from_id/deslike.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
  jijibot('sendphoto',[
  'chat_id'=>$chat_id,
'photo'=>$getuserphoto,
  'caption'=>"❤  Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like)👍",'callback_data'=>"like"],['text'=>"($deslike)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
jijibot('sendmessage',[
	'chat_id'=>$randmember,
	'text'=>"🤖 tizim xabari:

Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			  jijibot('sendphoto',[
  'chat_id'=>$randmember,
'photo'=>$getuserphoto2,
  'caption'=>"❤  Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like2)👍",'callback_data'=>"like"],['text'=>"($deslike2)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
}
else
{
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

⚠️ ulanmagan!

Bu mumkin:
1 kishi chatdan chiqdi
Navbatdagi foydalanuvchilarning soni 2 nafar va foydalanuvchilar suhbat bilan tanish emas

🔍 Navbatda turibmiz, bizning tizimimiz avtomatik tarzda foydalanuvchi bilan bog'lanadi, siz tezda qayta ishlashingiz mumkin.

Iltimos, suhbat tugmasini bosib, yana ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
}
if($textmassage=="🔙Orqaga" && $tc == "private"){
file_put_contents("data/$from_id/chat.txt","none");
$now = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
file_put_contents("data/$from_id/file.txt","none");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="❌Rad etish" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendmessage',[
				'chat_id'=>$nashnas,
	'text'=>" Chatga bo'lgan so'rovingiz $name dan rad etildi",
    		]);
file_put_contents("data/$from_id/chat.txt","none");
file_put_contents("data/$nashnas/chat.txt","none");
}
if($chat == "chatnashnas" && $tc == "private"){
if($textmassage != "✂️ Suhbatni yakunlang" && $textmassage != "✅Qabul qilish" && $textmassage != "❌Rad etish" && $textmassage != "Noto'g'ri xabar berish" && $textmassage != "✅Ha" && $textmassage != "❌Yoq" && $textmassage != "👁 Ma'lumotlarni ko'rsatish" &&$textmassage != "🚫Bloklash " && $textmassage != "Gunoh yo'q" && $textmassage != "▶ Keyingi kishi" && $textmassage != "👫 Do'stlarga qo'shing" && $textmassage != "Keling, keling") {
if ($vip == "") {
if ($update->message->text) {
jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"`$textmassage`",
	'parse_mode'=>'MarkDown',
    		]);
}
else
{
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

⚠️ hisobingiz ishlamaydi va media turiga ruxsat berilmadi ⚠️ ",
    		]);
}
}
}
}
if($chat == "chatnashnas" && $tc == "private"){
if($textmassage != "✂️ Suhbatni yakunlang" && $textmassage != "✅Qabul qilish" && $textmassage != "❌Rad etish" && $textmassage != "Noto'g'ri xabar berish" && $textmassage != "✅Ha" && $textmassage != "❌Yoq" && $textmassage != "👁 Ma'lumotlarni ko'rsatish" &&$textmassage != "🚫Bloklash" && $textmassage != "Gunoh yo'q" && $textmassage != "▶ Keyingi kishi" && $textmassage != "👫 Do'stlarga qo'shing" && $textmassage != "Keling, keling") {
if ($vip != "") {
$photo = $message->photo;
$file = $photo[count($photo)-1]->file_id;
$get = jijibot('getfile',['file_id'=>$file]);
$patch = $get->result->file_path;
file_put_contents("data/$from_id/photo.png",file_get_contents("https://api.telegram.org/file/bot$token/$patch"));
$document = $update->message->document;
$file = $document->file_id;
      $get = jijibot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
file_put_contents("data/$from_id/document.gif",file_get_contents("https://api.telegram.org/file/bot$token/$patch"));
$sticker = $update->message->sticker;
$file = $sticker->file_id;
      $get = jijibot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
file_put_contents("data/$from_id/sticker.webp",file_get_contents("https://api.telegram.org/file/bot$token/$patch"));
jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"`$textmassage`",
	'parse_mode'=>'MarkDown',
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$nashnas,
	'photo'=>new CURLFile("data/$from_id/photo.png"),
    		]);
						jijibot('senddocument',[
	'chat_id'=>$nashnas,
	'document'=>new CURLFile("data/$from_id/document.gif"),
    		]);
									jijibot('sendsticker',[
	'chat_id'=>$nashnas,
	'sticker'=>new CURLFile("data/$from_id/sticker.webp"),
    		]);
}
}
}
if($textmassage=="👁 Ma'lumotlarni ko'rsatish" && $tc == "private"){
if ($vip != "") {
$namenashnas = file_get_contents("data/$nashnas/name.txt");
$sennashnas = file_get_contents("data/$nashnas/age.txt");
$shahrnashans = file_get_contents("data/$nashnas/city.txt");
$jensyatnashans = file_get_contents("data/$nashnas/jenstyat.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari: $nashnas
 
🔘 Shaxsiy ma'lumotlar:

🗣 Ism: $nomenashnas
🙋🙋♂️ Jins: $jensyatnashans
Yosh: $sennashnas
🏫 Shahar: $shaharnashans ",
    		]);
}
else
{
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

 Shaxs ma'lumotlarini faqat maxsus hisob qaydnomasida aks ettiradi, ",
    		]);
}
}
if($textmassage=="Noto'g'ri xabar berish" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Sizning buzilish hisoboti administratorga yuborildi ✔️ ",
    		]);
			jijibot('sendmessage',[
				'chat_id'=>$Dev,
	'text'=>"🤖 tizim xabari:

⭕️ Quyidagi tomonidan buzilish hisoboti taqdim etildi:

Yuborganning tafsilotlari:

Id raqami: $from_id

Useri: @$sername
➖➖➖
- jinoyatni sodir qilgan shaxs: $nashnas
",
    		]);
}
if($textmassage=="✂️ Suhbatni yakunlang" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Chatingizni yopishga ishonchingiz komilmi?",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✅Ha"],['text'=>"❌Yoq"]
				],
			
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="▶ Keyingi kishi" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

- Siz bu gapni kesib, yashirin suhbatga o'tishni xohlaysizmi?",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Keling, keling"],['text'=>"❌Yoq"]
				],
			
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="🚫Bloklash" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

 Ushbu suhbatni tugatishni xohlaysizmi va hech qachon ushbu foydalanuvchi bilan bog'lanmaysizmi? ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Tishlarni kesib oling 😜"],['text'=>"Gunoh yo'q"]
				],			
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="❌Yoq" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:
 
OK OK

😃Bilganizi qilin, suhbatni davom eting ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="👫 Do'stlarga qo'shing" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Do'stlar ro'yxatiga qo'shilgan 😻

Bilinglarsiz, suhbatni davom eting ",
    		]);
$id = base64_encode($nashnas);
$name = file_get_contents("data/$nashnas/name.txt");
$gpadd = fopen("data/$from_id/frinds.txt",'a') or die("Unable to open file!");  
fwrite($gpadd,"[$name](https://t.me/$usernamebot?start=$id)\n");
fclose($gpadd);
}
if($textmassage=="Gunoh yo'q" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:
 
OK OK

Bilinglarsiz, suhbatni davom eting ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
if($textmassage=="✅Ha" && $tc == "private"){
file_put_contents("data/$from_id/chat.txt","none");
file_put_contents("data/$nashnas/chat.txt","none");
$now = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$members = file_get_contents('data/chat.txt');
$now1 = str_replace("$nashnas\n","",$members);
file_put_contents("data/chat.txt","$now1");
$newnumchat = $numchat -1;
file_put_contents("data/$from_id/numchat.txt","$newnumchat");
$numchat1 = file_get_contents("data/$nashnas/numchat.txt");
$newnumchat1 = $numchat1 -1;
file_put_contents("data/$nashnas/numchat.txt","$newnumchat1");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Suhbat muvaffaqiyatli tugatildi ✔️

Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"Suhbat boshqa tomondan ☹️️ tomonidan yopildi
 
Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$nashnas,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
}
if($textmassage=="Keling, keling" && $tc == "private"){
file_put_contents("data/$nashnas/chat.txt","none");
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
$members = file_get_contents('data/chat.txt');
$now1 = str_replace("$nashnas\n","",$members);
file_put_contents("data/chat.txt","$now1");
$newnumchat = $numchat -1;
file_put_contents("data/$from_id/numchat.txt","$newnumchat");
$numchat1 = file_get_contents("data/$nashnas/numchat.txt");
$newnumchat1 = $numchat1 -1;
file_put_contents("data/$nashnas/numchat.txt","$newnumchat1");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Suhbat muvaffaqiyatli tugatildi ✔️

Kutish ro'yxatida 🎉

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"Suhbat boshqa tomondan ☹️️ tomonidan yopildi

Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$nashnas,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
}
if($textmassage=="Tishlarni kesib oling 😜" && $tc == "private"){
file_put_contents("data/$from_id/chat.txt","none");
file_put_contents("data/$nashnas/chat.txt","none");
$now = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$members = file_get_contents('data/chat.txt');
$now1 = str_replace("$nashnas\n","",$members);
file_put_contents("data/chat.txt","$now1");
$newnumchat = $numchat -1;
file_put_contents("data/$from_id/numchat.txt","$newnumchat");
$numchat1 = file_get_contents("data/$nashnas/numchat.txt");
$newnumchat1 = $numchat1 -1;
file_put_contents("data/$nashnas/numchat.txt","$newnumchat1");
$gpadd = fopen("data/$from_id/blacklist.txt",'a') or die("Unable to open file!");  
$name = file_get_contents("data/$nashnas/name.txt");
$id = base64_encode($nashnas);
fwrite($gpadd,"[$name](https://t.me/$usernamebot?start=$id)\n");
fclose($gpadd);
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Suhbat muvaffaqiyatli tugatildi ✔️

🚫 Foydalanuvchi bloklandi

Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$nashnas,
	'text'=>"Suhbat boshqa tomondan ☹️️ tomonidan yopildi
 
🚫Oh, uh, sizni to'sib qo'ydi, nima qildingiz?
 
Robotning asosiy menyusiga xush kelibsiz

🔻 Quyidagi tugmalardan foydalaning 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari"]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			jijibot('sendphoto',[
	'chat_id'=>$nashnas,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki boshqa chat xonalari yo'qmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

🤖 robotingizni ixtisoslashtiring, ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
}
elseif($data=="like"){
$like = file_get_contents("data/$nashnas2/like.txt");
$pluslike = $like +1;
file_put_contents("data/$nashnas2/like.txt","$pluslike");
         jijibot('sendmessage',[
             'chat_id'=>$chatid,
  'message_id'=>$messageid,
  'text'=>"📣 Helle Idonna o'z sevgisiga illyuzionlikni yoqtiradi
👍 Uning sevganlari: $pluslike ",
	]);
	            jijibot('deletemessage',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
           ]);
	}
	elseif($data=="deslike"){
$like = file_get_contents("data/$nashnas2/deslike.txt");
$pluslike = $like + 1;
file_put_contents("data/$nashnas2/deslike.txt","$pluslike");
         jijibot('sendmessage',[
             'chat_id'=>$chatid,
  'message_id'=>$messageid,
  'text'=>"📣 Helle Idonna o'z sevgisiga illyuzionlikni yoqtiradi
👍 Uning sevganlari: $pluslike ",
	]);
	            jijibot('deletemessage',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
           ]);
	}
elseif($textmassage=="👩‍🎓Ayol" && $tc == "private"){
if ($vip != "") {
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
file_put_contents("data/$from_id/chat.txt","girl");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz muvaffaqiyatli ro'yxatga kiritdingiz ✔️

 Foydalanuvchini qidirishda, suhbatni boshlashni kuting ... ",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatni haqorat qilish yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing. ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
			]);
}
else
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robot siz uchun maxsus emas

Iltimos, robotingizni yangilashga harakat qiling ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
{
}
}
elseif($textmassage=="👨‍🎓Erkak" && $tc == "private"){
if ($vip != "") {
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
file_put_contents("data/$from_id/chat.txt","boy");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz muvaffaqiyatli ro'yxatga kiritdingiz ✔️

The Foydalanuvchini qidirishda, suhbatni boshlashni kuting ... ",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatni haqorat qilish yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing. ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
			]);
}
else
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robot siz uchun maxsus emas

Iltimos, robotingizni yangilashga harakat qiling ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
{
}
}
elseif($textmassage=="👫Shu yoshda" && $tc == "private"){
if ($vip != "") {
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);
file_put_contents("data/$from_id/chat.txt","age");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Siz muvaffaqiyatli ro'yxatga kiritdingiz ✔️

 Foydalanuvchini qidirishda, suhbatni boshlashni kuting ... ",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatni haqorat qilish yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing. ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
			]);
}
else
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robot siz uchun maxsus emas

Iltimos, robotingizni yangilashga harakat qiling ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);
{
}
}
elseif($textmassage=="📍Bir joydan bilan chat [yopish]" && $tc == "private"){
if ($vip != "" && $adds > 5) {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Avval joylashuvingizni topshirishingiz kerak

ℹ Yordam:
 Joylashuvning joylashgan manzilini so'rash uchun quyidagi tugmani foydalaning, so'ng xaritaga kirib manzilingizni tanlang yoki xaritada avtomatik ravishda joylashuvingizni topish uchun GPS manzilini yoqish uchun GPS-dan foydalaning. ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"🏚 yuborish holati","request_location" =>true],['text'=>"🔙Orqaga"]
				],	
 	],
            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/file.txt","sendloc");
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Robot bu erda sizga xos emas

Robotingizni yangilang

You Siz taklif qilgan odamlar soni: $adds
To'ldirilishi majburiy bo'lgan odam soni 5dan ortiq bolishi kerek ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"⭐️️ robotni yangilang",'callback_data'=>"vip"]
	],
	],
        ])
    		]);

}
}
elseif($step == "sendloc" && $tc == "private"){   
if($update->message->location){	
$rand = rand(4,30);
$rand2 = rand(1,10);
			jijibot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"📍 Sizning manzilingiz tizimda saqlanadi ...",
	]);	
			jijibot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"🤖 tizim xabari:

Kuzatuvchi muvaffaqiyatli topilgan

⭕️ Chat qoidalari:
So'zni yuborishga harakat qiling
2 ta e'lon joylashtirmang
Chatni haqorat qilish yoki yopishmang

⚠️ Agar yuqorida sanab o'tilganlardan hech birini kuzatmasangiz, siz robotdan bloklanadi

Suhbatni boshlash uchun quyidagi tugmani bosing

Sizning shaxsingizga tegishli bo'lgan masofa: $rand. $rand2 KM ",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
	]);
$add = fopen("data/chat.txt",'a') or die("Unable to open file!");  
fwrite($add, "$from_id\n");
fclose($add);	
file_put_contents("data/$from_id/chat.txt","dont");
file_put_contents("data/$from_id/file.txt","none");
	}
	}
$memberex = explode("\n",$member);
$howmember = count($memberex) - 1;
$randmember = $memberex[mt_rand(0,$howmember)];
$getgirl = file_get_contents("data/$randmember/age.txt");
if($chat == "girl" && $tc == "private"){
if($textmassage == "Chatni boshlang") {
if ($getgirl == "ayol"){
if ($randmember != $from_id && $randmember != ""){
file_put_contents("data/$from_id/chat.txt","chatnashnas");
file_put_contents("data/$randmember/chat.txt","chatnashnas");
file_put_contents("data/$randmember/nashnas.txt","$from_id");
file_put_contents("data/$from_id/nashnas.txt","$randmember");
$aval = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$dovom = str_replace("$randmember\n","",$member);
file_put_contents("data/chat.txt","$now");
$getuserprofile = getUserProfilePhotos($token,$randmember);
$cuphoto = $getuserprofile->total_count;
$getuserphoto = $getuserprofile->photos[0][0]->file_id;
$getuserprofile2 = getUserProfilePhotos($token,$from_id);
$cuphoto2 = $getuserprofile2->total_count;
$getuserphoto2 = $getuserprofile2->photos[0][0]->file_id;
$like = file_get_contents("data/$randmember/like.txt");
$deslike = file_get_contents("data/$randmember/deslike.txt");
$like2 = file_get_contents("data/$from_id/like.txt");
$deslike2 = file_get_contents("data/$from_id/deslike.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
  jijibot('sendphoto',[
  'chat_id'=>$chat_id,
'photo'=>$getuserphoto,
  'caption'=>"❤ Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like)👍",'callback_data'=>"like"],['text'=>"($deslike)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
jijibot('sendmessage',[
	'chat_id'=>$randmember,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			  jijibot('sendphoto',[
  'chat_id'=>$randmember,
'photo'=>$getuserphoto2,
  'caption'=>"❤ Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like2)👍",'callback_data'=>"like"],['text'=>"($deslike2)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
}
}
else
{
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

⚠️ ulanmagan!

Bu mumkin:
1ype_user chatdan chiqdi
Navbatdagi foydalanuvchilarning soni 2 nafar va foydalanuvchilar suhbat bilan tanish emas


🔍 Navbatda turibmiz, bizning tizimimiz avtomatik tarzda foydalanuvchi bilan bog'lanadi, siz tezda qayta ishlashingiz mumkin.

Iltimos, suhbat tugmasini bosib, yana ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
}
$memberex = explode("\n",$member);
$howmember = count($memberex) - 1;
$randmember = $memberex[mt_rand(0,$howmember)];
$getgirl = file_get_contents("data/$randmember/jenstyat.txt");
if($chat == "boy" && $tc == "private"){
if($textmassage == "Chatni boshlang") {
if ($getgirl == "erkak"){
if ($randmember != $from_id && $randmember != ""){
file_put_contents("data/$from_id/chat.txt","chatnashnas");
file_put_contents("data/$randmember/chat.txt","chatnashnas");
file_put_contents("data/$randmember/nashnas.txt","$from_id");
file_put_contents("data/$from_id/nashnas.txt","$randmember");
$aval = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$dovom = str_replace("$randmember\n","",$member);
file_put_contents("data/chat.txt","$now");
$getuserprofile = getUserProfilePhotos($token,$randmember);
$cuphoto = $getuserprofile->total_count;
$getuserphoto = $getuserprofile->photos[0][0]->file_id;
$getuserprofile2 = getUserProfilePhotos($token,$from_id);
$cuphoto2 = $getuserprofile2->total_count;
$getuserphoto2 = $getuserprofile2->photos[0][0]->file_id;
$like = file_get_contents("data/$randmember/like.txt");
$deslike = file_get_contents("data/$randmember/deslike.txt");
$like2 = file_get_contents("data/$from_id/like.txt");
$deslike2 = file_get_contents("data/$from_id/deslike.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
  jijibot('sendphoto',[
  'chat_id'=>$chat_id,
'photo'=>$getuserphoto,
  'caption'=>"❤ Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like)👍",'callback_data'=>"like"],['text'=>"($deslike)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
jijibot('sendmessage',[
	'chat_id'=>$randmember,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			  jijibot('sendphoto',[
  'chat_id'=>$randmember,
'photo'=>$getuserphoto2,
  'caption'=>"❤  Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like2)👍",'callback_data'=>"like"],['text'=>"($deslike2)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
}
}
else
{
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

⚠️ ulanmagan!

Bu mumkin:
1ype_user chatdan chiqdi
Navbatdagi foydalanuvchilarning soni 2 nafar va foydalanuvchilar suhbat bilan tanish emas

🔍 Navbatda turibmiz, bizning tizimimiz avtomatik tarzda foydalanuvchi bilan bog'lanadi, siz tezda qayta ishlashingiz mumkin.

Iltimos, suhbat tugmasini bosib, yana ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
}
$memberex = explode("\n",$member);
$howmember = count($memberex) - 1;
$randmember = $memberex[mt_rand(0,$howmember)];
$getgirl = file_get_contents("data/$randmember/age.txt");
if($chat == "age" && $tc == "private"){
if($textmassage == "Chatni boshlang") {
if ($getgirl == "$age"){
if ($randmember != $from_id && $randmember != ""){
file_put_contents("data/$from_id/chat.txt","chatnashnas");
file_put_contents("data/$randmember/chat.txt","chatnashnas");
file_put_contents("data/$randmember/nashnas.txt","$from_id");
file_put_contents("data/$from_id/nashnas.txt","$randmember");
$aval = str_replace("$from_id\n","",$member);
file_put_contents("data/chat.txt","$now");
$dovom = str_replace("$randmember\n","",$member);
file_put_contents("data/chat.txt","$now");
$getuserprofile = getUserProfilePhotos($token,$randmember);
$cuphoto = $getuserprofile->total_count;
$getuserphoto = $getuserprofile->photos[0][0]->file_id;
$getuserprofile2 = getUserProfilePhotos($token,$from_id);
$cuphoto2 = $getuserprofile2->total_count;
$getuserphoto2 = $getuserprofile2->photos[0][0]->file_id;
$like = file_get_contents("data/$randmember/like.txt");
$deslike = file_get_contents("data/$randmember/deslike.txt");
$like2 = file_get_contents("data/$from_id/like.txt");
$deslike2 = file_get_contents("data/$from_id/deslike.txt");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
 		]);
  jijibot('sendphoto',[
  'chat_id'=>$chat_id,
'photo'=>$getuserphoto,
  'caption'=>"❤ Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like)👍",'callback_data'=>"like"],['text'=>"($deslike)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
jijibot('sendmessage',[
	'chat_id'=>$randmember,
	'text'=>"🤖 tizim xabari:
Chat boshlandi ✅

Hamkasbini tinglang, ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"✂️ Suhbatni yakunlang"],['text'=>"Noto'g'ri xabar berish"]
				],
[				
				['text'=>"👁 Ma'lumotlarni ko'rsatish"],['text'=>"🚫Bloklash"]
				],
												[				
				['text'=>"▶ Keyingi kishi"],['text'=>"👫 Do'stlarga qo'shing"]
				],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
			  jijibot('sendphoto',[
  'chat_id'=>$randmember,
'photo'=>$getuserphoto2,
  'caption'=>"❤ Do'stingizning profil fotosurati yoqdimi yoki yo'qmi?",
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"($like2)👍",'callback_data'=>"like"],['text'=>"($deslike2)👎",'callback_data'=>"deslike"]
	],
	],
        ])
   ]);
}
}
else
{
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 tizim xabari:

⚠️ ulanmagan!

Bu mumkin:
1ype_user chatdan chiqdi
Navbatdagi foydalanuvchilarning soni 2 nafar va foydalanuvchilar suhbat bilan tanish emas


🔍 Navbatda turibmiz, bizning tizimimiz avtomatik tarzda foydalanuvchi bilan bog'lanadi, siz tezda qayta ishlashingiz mumkin.

Iltimos, suhbat tugmasini bosib, yana ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Chatni boshlang"]
				],
								[
				['text'=>"🔙Orqaga"]
				],		
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
}
elseif($textmassage=="💎 Hisob malumotlari" && $tc == "private"){
if ($vip != "") {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📌 Hisobingiz haqida ma'lumot:
➖➖➖➖➖

1 Sizning ismingiz: $ ismingiz
Sizning yoshingiz: $jenstyat
Sizning 3 ballingiz: $age
Sizning shaharingiz $city
5-Hisob turi: maxsus
Taklifchilar soni: $adds
Profilingizdagi fotosuratlar like soni: $like
Sizning profilingiz suratingizga salbiy salbiy ta'sir qiladi: $deslike

➖➖➖➖➖",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"✏Chiqishlarni tahrirlash"],['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📌 Hisobingiz haqida ma'lumot:
➖➖➖➖➖

1 Sizning ismingiz: $ ismingiz
Sizning yoshingiz: $jenstyat
Sizning 3 ballingiz: $age
Sizning shaharingiz $city
5-Hisob turi: maxsus
Taklifchilar soni: $adds
Profilingizdagi fotosuratlar like soni: $like
Sizning profilingiz suratingizga salbiy salbiy ta'sir qiladi: $deslike

➖➖➖➖➖",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"✏Chiqishlarni tahrirlash"],['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
}
}
elseif($textmassage=="✏Chiqishlarni tahrirlash" && $tc == "private"){
if ($editinfo == "") {
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 Ma'lumotni tahrirlash bo'limiga xush kelibsiz

Tahrir qilmoqchi bo'lgan qismni tanlang

⚠️ Diqqat faqatgina bir marta bo'lishi mumkin ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"1️⃣Yoshni tahrir qilish"],['text'=>"2️⃣Viloyatni tahrirlash"]
				],
								[
				['text'=>"3️⃣Jinsni tahrir qilish"],['text'=>"4️⃣Ismni tahrir qilish"]
				],
												[
				['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
			]);
file_put_contents("data/$from_id/edit.txt","true");
}
else
{
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📌 Siz ushbu bo'limni bir marta ishlatdingiz

Qayta foydalanish mumkin emas ",
			]);
}
}
elseif($textmassage=="1️⃣Yoshni tahrir qilish" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 Yoshingizni tanlang",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"13"],['text'=>"14"],['text'=>"15"],['text'=>"16"]
				],
								[
				['text'=>"17"],['text'=>"18"],['text'=>"19"],['text'=>"20"]
				],
								[
				['text'=>"21"],['text'=>"22"],['text'=>"23"],['text'=>"24"]
				],
								[
				['text'=>"25"],['text'=>"26"],['text'=>"27"],['text'=>"28"]
				],
								[
				['text'=>"29"],['text'=>"30"],['text'=>"31"],['text'=>"32"]
				],
								[
				['text'=>"32 +"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
			]);
file_put_contents("data/$from_id/select.txt","editage");
}
elseif($select == "editage" && $tc == "private"){
if ($textmassage <= 50 && $textmassage >= 14){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Saqlandi✔️",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"1️⃣Yoshni tahrir qilish"],['text'=>"2️⃣Viloyatni tahrirlash"]
				],
								[
				['text'=>"3️⃣Jinsni tahrir qilish"],['text'=>"4️⃣Ismni tahrir qilish"]
				],
												[
				['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/age.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","none");
}
}
elseif($textmassage=="2️⃣Viloyatni tahrirlash" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻 Kerakli viloyatni tanlang🔻",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"Toshkent"],['text'=>"Buxoro"],['text'=>"Navoi"]
				],
								[
				['text'=>"Xorazm"],['text'=>"Nukus"],['text'=>"Andijon"]
				],
								[
				['text'=>"Fargona"],['text'=>"Jizzax"],['text'=>"Qashqadaryo"]
				],
								[
				['text'=>"Surxondaryo"],['text'=>"Guliston"],['text'=>"Xiva"]
				],
								[
				['text'=>"Samarqand"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
			]);
file_put_contents("data/$from_id/select.txt","editcity");
}
elseif($select == "editcity" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Saqlandi✔️",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"1️⃣Yoshni tahrir qilish"],['text'=>"2️⃣Viloyatni tahrirlash"]
				],
								[
				['text'=>"3️⃣Jinsni tahrir qilish"],['text'=>"4️⃣Ismni tahrir qilish"]
				],
												[
				['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/city.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","none");
}
elseif($textmassage=="3️⃣Jinsni tahrir qilish" && $tc == "private"){
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻 Jinsingizni kiriting🔻",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
				['text'=>"👩‍🎓Ayol"],['text'=>"👨‍🎓Erkak"]
				],
 	],
            	'resize_keyboard'=>true
       		])
			]);
file_put_contents("data/$from_id/select.txt","editsex");
}
elseif($select == "editsex" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Saqlandi ✔️",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				 ['text'=>"1️⃣Yoshni tahrir qilish"],['text'=>"2️⃣Viloyatni tahrirlash"]
				],
								[
				['text'=>"3️⃣Jinsni tahrir qilish"],['text'=>"4️⃣Ismni tahrir qilish"]
				],
												[
				['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/jenstyat.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","none");
}
elseif($textmassage=="4️⃣Ismni tahrir qilish" && $tc == "private"){
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻 Ismingizni yozing 🔻",
			]);
file_put_contents("data/$from_id/select.txt","editname");
}
elseif($select == "editname" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Saqlandi ✔️",
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"1️⃣Yoshni tahrir qilish"],['text'=>"2️⃣Viloyatni tahrirlash"]
				],
								[
				['text'=>"3️⃣Jinsni tahrir qilish"],['text'=>"4️⃣Ismni tahrir qilish"]
				],
												[
				['text'=>"🔙Orqaga"]
				],
				],
				            	'resize_keyboard'=>true
       		])
    		]);
file_put_contents("data/$from_id/name.txt","$textmassage");
file_put_contents("data/$from_id/select.txt","none");
}
elseif($textmassage=="🏅 Maxsus hisob" && $tc == "private"){
$cheghadr = 5 -$adds;
	jijibot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://titanteam.ga/chat/vip.jpg",
	'caption'=>"Siz suhbatlashgan odamlar bilan suhbatlashmoqchimisiz? 😃
Yoki endi suhbatlashish xonasi bo'lmaganmi?
Yoki sizga kino video yoki xohlagan narsalarni yuborishingiz mumkinmi?

Quyidagi usullardan birini tanlang: 🔻 ",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"👥Boshqalarni taklif qiling"],['text'=>"💎To'lovni to'lang"]
				],
								[
				['text'=>"🔙 برگشت"]
				],
				],
				            	'resize_keyboard'=>true
       		])
			]);
}
elseif($textmassage=="🚫 Bloklash ro'yxati" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍Sizning hisobingiz ro'yxati:
➖➖➖➖
$blacklist",
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
 'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"🔙Orqaga"],['text'=>"❌Ro'yxatni o'chirish"]
				],
				],
				            	'resize_keyboard'=>true
       		])
			]);
}
elseif($textmassage=="👫 Do'stlar ro'yxati" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍Dostlaringiz royhati:
➖➖➖➖
$frinds",
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
			]);
}
elseif($textmassage=="❌Ro'yxatni o'chirish" && $tc == "private"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 Bloklaringiz ro'yxati butunlay tozalangan",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
			[
				['text'=>"💬Anonim suhbat"]
				],
								[
				['text'=>"🏅 Maxsus hisob"],['text'=>"💎 Hisob malumotlari "]
				],
												[
				['text'=>"👫 Do'stlar royxati"],['text'=>"🚫 Bloklash royxati"]
				],
																[
				['text'=>"📍 Yordam"],['text'=>"🔖 Yordam"],['text'=>"🤖 Robot haqida"]
				],
				
 	],
            	'resize_keyboard'=>true
       		])
			]);
unlink("data/$from_id/blacklist.txt");
}
elseif($textmassage=="/vip" or $textmassage=="👥Boshqalarni taklif qiling" && $tc == "private"){
$cheghadr = 3 -$adds;
			jijibot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://titanteam.ga/chat/baner.jpg",
	'caption'=>"Minglab foydalanuvchi nomi bilan yashirin robot
Oh, bu buyuk robot raqibing kimligini bilmasdan suhbatlashishi mumkin! ㊣

Nima kutmoqdasiz?
https://t.me/$usernamebot?start=$from_id",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Yuqoridagi bayroq do'stlaringiz, guruhingiz va kanalingiz uchun taklifnomangizni o'z ichiga oladi va to'plamingiz bilan maxsus bonusni taqdim etasiz.",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>" Siz taklif qilgan odamlar soni: $adds

Maxsus robot sifatida taklif etiladigan odamlarning soni: $cheghadr ",
    		]);
}
elseif($data == "vip"){
$cheghadr = 3 -$adds2;
			jijibot('sendphoto',[
	'chat_id'=>$chatid,
	'photo'=>"https://titanteam.ga/chat/baner.jpg",
	'caption'=>"Minglab foydalanuvchi nomi bilan yashirin robot
Oh, bu buyuk robot raqibing kimligini bilmasdan suhbatlashishi mumkin! ㊣

Nima kutmoqdasiz?
https://t.me/$usernamebot?start=$fromid",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"👆🏻 Yuqoridagi bayroq do'stlaringiz, guruhingiz va kanalingiz uchun taklifnomangizni o'z ichiga oladi va to'plamingiz bilan maxsus bonusni taqdim etasiz.👆🏻",
    		]);
			jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"📌Siz taklif qilgan odamlar soni: $adds

Maxsus robot sifatida taklif etiladigan odamlarning soni: $cheghadr  ",
    		]);
}
elseif($textmassage=="💎To'lovni to'lang" && $tc == "private"){
			jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Hisobingiz uchun 3 ming som to'lashingiz va fantastik robotning xususiyatlaridan foydalanishingiz mumkin

Maxsus Xususiyatlar Bot ro'yxati:

1-suhbatni boshqa taraf bilan ajratish imkoniyati
2 GPS va yaqin odamlar bilan suhbatlashish
3️⃣ Qarama-qarshi tomonning profilini ko'rish
Cheksiz suhbatlashish va ...

⭐️️ va qo'shimcha qo'shimcha funktsiyalar ... ",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🚀Sotib olish",'url'=>"https://t.me/hacker_oken"]
	],
              ]
        ])
    		]);
}
elseif ($vip == "") {
if($adds  >= 3 && $tc == "private"){
file_put_contents("data/$from_id/vip.txt","true");
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎉 Tabriklaymiz 🎉

Hisobingiz maxsus ✅ edi
Mehmonlar soni: $adds »",
    		]);
}
}
if($textmassage=="🤖 Robot haqida" && $tc == "private"){
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"Telegram aqilli roboti (anonim suhbat)
➖➖➖
Sirli suhbat, telegram robotining taxallusiga ega bo'lgan ijtimoiy robotdir

Sizga aziz bo'lgan Uzbeklar uchun do'stona va quvnoq suhbat uchun aqlli robot

Ushbu robotning dasturlash va umumiy ishini:
@CoDeR_ChiK yozdi

To'liq zahiralangan! ✅

🆔 @$usernamebot ",
	]);
	}
if($textmassage=="📍 Yordam" && $tc == "private"){
file_put_contents("data/$from_id/file.txt","nazar");
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"Sizning fikr-mulohazangiz bizga dalda beradi
➖➖➖➖➖
Bizga takliflaringizni va sharhlaringizni bizga yuboring
➖➖➖
Xabaringizni kiriting ",
                 'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[
	['text'=>"🔙Orqaga"]
	],
	]
	])
	
	]);
	}
elseif($step == "nazar" && $tc == "private"){   
if ($textmassage != "🔙Orqaga") {	
unlink("data/$from_id.txt");
jijibot('ForwardMessage',[
'chat_id'=>$Dev,
'from_chat_id'=>$chat_id,
'message_id'=>$message_id
]);
			jijibot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"✔ Siz xabaringiz  yuborildi. \nRahmat",
	]);	
	}
	}
elseif($update->message && $rt && $from_id == $Dev && $tc == "private"){
if($update->message->text){
	jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"Sizning xabaringiz hammaga yuborilgan",
		]);
	jijibot('sendmessage',[
        "chat_id"=>$reply,
        "text"=>"Siz uchun habar:

`$textmassage`",
'parse_mode'=>'MarkDown'
		]);
}
}
if($textmassage=="🔖 Yordam" && $tc == "private"){
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"Telegram aqilli roboti (anonim suhbat)
➖➖➖
Sirli suhbat, telegram robotining taxallusiga ega bo'lgan ijtimoiy robotdir

Sizga aziz bo'lgan Uzbeklar uchun do'stona va quvnoq suhbat uchun aqlli robot

Ushbu robotning dasturlash va umumiy ishini:
@CoDeR_ChiK yozdi

To'liq zahiralangan! ✅

🆔 @$usernamebot ",
	]);
	}
//==============================================================
//panel admin
if($textmassage=="/panel" or $textmassage=="panel" or $textmassage=="مدیریت" or $textmassage=="/start panel" && $from_id == $Dev){
if ($tc == "private") {
if ($from_id == $Dev) {
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Siz panel bolimidasiz",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"💥Statistika"],['text'=>"🔆 ixtisoslashtir"]                    
		 ],
 	[
	  	['text'=>"Hammaga yuboring"],['text'=>"📍 Jamoatxonalar"]
	  ],
	   	[
	  	['text'=>"Onlayn odamlar"],['text'=>"⛔️ blokirovkalash"]
	  ],
	   	[
	  	['text'=>"🔙Orqaga"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
}
elseif($textmassage=="⛔️ blokirovkalash" && $from_id == $Dev){
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"Iltimos, foydalanuvchiga xabar yuboring yoki idisini kiriting",
   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"Orqaga🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
		]);
file_put_contents("data/$from_id/file.txt","block");
		}
elseif ($step == 'block' && $from_id == $Dev) {
if ($textmassage != "Orqaga🔙") {
if ($forward_from == true) {
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Bloklandi ✔️

🔹🆔: $forward_from_id
🔸Ismi: @$forward_from_username",
	  'reply_to_message_id'=>$message_id,
 ]);
$adduser = file_get_contents("data/blocklist.txt");
$adduser .= $forward_from_id . "\n";
file_put_contents("data/blocklist.txt", $adduser);
file_put_contents("data/$from_id/file.txt","none");
}
else
{
	         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Foydalanuvchi robot tomonidan muvaffaqiyatli bloklandi✔️

🔹Xabar : $textmassage",
	  'reply_to_message_id'=>$message_id,
 ]);
$adduser = file_get_contents("data/blocklist.txt");
$adduser .= $textmassage . "\n";
file_put_contents("data/blocklist.txt", $adduser);
file_put_contents("data/$from_id/file.txt","none");
}
}
}
elseif($textmassage=="Onlayn odamlar" && $from_id == $Dev){
	$member1 = file_get_contents("data/chat.txt");
	$member2 = explode("\n",$member1);
                        $how = count($member2) -1 ;
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖Xozir onlaynlar: $how",
                'hide_keyboard'=>true,
		]);
		}
elseif($textmassage=="💥Statistika" && $from_id == $Dev){
                        $mmemcount = count($members) -1 ;
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"Bot azolari: $mmemcount",
                'hide_keyboard'=>true,
		]);
		}
elseif ($textmassage == 'Hammaga yuboring' && $from_id == $Dev) {
file_put_contents("data/$from_id/file.txt","sendtoall");
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Iltimos, matningizni yuboring🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"Orqaga🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
elseif ($step == 'sendtoall' && $from_id == $Dev) {
file_put_contents("data/$from_id/file.txt","none");
if ($textmassage != "Orqaga🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Xabar muvaffaqiyatli yuborildi✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$mem = fopen( "Member.txt", 'r');
    while( !feof( $mem)) {
    $memuser = fgets( $mem);
     jijibot('sendmessage',[
          'chat_id'=>$memuser,        
		  'text'=>$textmassage,
        ]);
    }
}
}
elseif ($textmassage == '📍 Jamoatxonalar' && $from_id == $Dev) {
file_put_contents("data/$from_id/file.txt","fortoall");
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Iltimos, matningizni oldinga o'tkazing🚀",
				  'reply_to_message_id'=>$message_id,
				   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"Orqaga🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
    		]);
}
elseif ($step == 'fortoall' && $from_id == $Dev) {
file_put_contents("data/$from_id/file.txt","none");
if ($textmassage != "Orqaga🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Xabar muvaffaqiyatli yuborildi✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
$mem = fopen( "Member.txt", 'r');
    while( !feof( $mem)) {
    $memuser = fgets( $mem);
Forward($memuser, $chat_id,$message_id);
    }
}
}
if ($textmassage == 'Orqaga🔙' && $from_id == $Dev) {
file_put_contents("data/$from_id.txt","none");
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦Siz admin paneliga qaytdingiz",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"💥Statistika"],['text'=>"🔆 ixtisoslashtir"]                    
		 ],
 	[
	  	['text'=>"Hammaga yuboring"],['text'=>"📍 Jamoatxonalar"]
	  ],
	   	[
	  	['text'=>"Onlayn odamlar"],['text'=>"⛔️ blokirovkalash"]
	  ],
	   	[
	  	['text'=>"🔙Orqaga"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
elseif ($textmassage == '🔆 ixtisoslashtir' && $from_id == $Dev) {
file_put_contents("data/$from_id/file.txt","setvip");
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Iltimos, foydalanuvchiga xabar yuboring yoki Idisini kiriting",
				  'reply_to_message_id'=>$message_id,
				     'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"Orqaga🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
    ]);
}
elseif ($step == 'setvip' && $from_id == $Dev) {
if ($textmassage != "🔙Orqaga") {
if ($forward_from == true) {
         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Foydalanuvchiga maxsus targibot qilindi:

🔹🆔 : $forward_from_id
🔸Ismi : @$forward_from_username",
	  'reply_to_message_id'=>$message_id,
 ]);
file_put_contents("data/$forward_from_id/vip.txt","true");
file_put_contents("data/$from_id/file.txt","none");
}
else
{
	         jijibot('sendmessage',[
        	'chat_id'=>$Dev,
        	'text'=>"Foydalanuvchi ✔ spec maxsus targ'ibot qilindi 

🔹Xabar : $textmassage",
	  'reply_to_message_id'=>$message_id,
 ]);
file_put_contents("data/$textmassage/vip.txt","true");
file_put_contents("data/$from_id/file.txt","none");
}
}
}
unlink("error_log");
?>