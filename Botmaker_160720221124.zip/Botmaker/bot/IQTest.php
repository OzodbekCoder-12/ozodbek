﻿<?php

ob_start();

define('API_KEY','[*BOTTOKEN*]');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
//bu codni @Neoonsters yozgan!!!!!!
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$mid = $message->message_id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$u = explode("\n",file_get_contents("memb.txt"));
$c = count($u)-1;
$modxe = file_get_contents("usr.txt");
$admin = "[*ADMIN*]";
if($text=="/start" or "/Start"){
    bot('sendmessage',[
        'chat_id'=>$chat_id,
        'text'=>"Привет выберите язык!
Salom tilni tanglang!
Hello choose your language!",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>'🇷🇺Русский🇷🇺', 'callback_data' => "rus"],['text'=>'🇺🇿Ozbekcha🇺🇿', 'callback_data' => "uzb"]],
            ]
        ]),
        ]);

}
if($data=="rus"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Привет бот для тестирования! Можете проверить свое IQ !
Много других интересных и увлекательных тестов!,",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Тест на IQ",'callback_data'=>"iq"]],
   [['text'=>"Тест на тупизм",'callback_data'=>"dau"]],
]
       ])
  ]);   
}
if($data=="uzb"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Salom sinov uchun! IQ ni tekshirishingiz mumkin!
Ko'p boshqa qiziqarli va hayajonli testlar!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"IQ testi",'callback_data'=>"iquzb"]],
  [['text'=>"Jillilik test",'callback_data'=>"daun"]],
]
       ])
  ]);
}
if($data=="iquzb"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Salom! IQ sinovini boshlash uchun quyida joylashgan start tugmasini bosing.!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Boshlash",'callback_data'=>"quzb"]],
 [['text'=>"Orqaga",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="iq"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Привет! Чтобы начать тест на IQ нажмите ниже кнопку начать!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Начать",'callback_data'=>"qu"]],
 [['text'=>"Назад",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="quzb"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"1.Kim bu erda ortiqcha?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Arslon",'callback_data'=>"leva"],['text'=>"Tiger",'callback_data'=>"tigar"]],
[['text'=>"gepard",'callback_data'=>"geparda"],['text'=>"Hyena",'callback_data'=>"gienaa"]],
]
       ])
  ]);
}
if($data=="daun"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"1.Siz messengerlada qancha vaqt otkazasiz?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"24 soat",'callback_data'=>"taq"],['text'=>"12 soat",'callback_data'=>"taqw"]],
]
       ])
  ]);
}
if($data=="dau"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"1.Сколько времени вы проводите в месенджерах?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"24 часа",'callback_data'=>"tmen"],['text'=>"12 часов",'callback_data'=>"tme"]],
]
       ])
  ]);
}
if($data=="tme"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"2.Сколько воемени вы спите?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"6 часов",'callback_data'=>"poa"],['text'=>"12 часов",'callback_data'=>"pow"]],
]
       ])
  ]);
}
if($data=="tmen"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"2.Сколько воемени вы спите?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"6 часов",'callback_data'=>"poa"],['text'=>"12 часов",'callback_data'=>"pow"]],
]
       ])
  ]);
}
if($data=="poa"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"3.Читаете ли вы книги?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Да",'callback_data'=>"naqa"],['text'=>"Нет",'callback_data'=>"naqas"]],
]
       ])
  ]);
}
if($data=="pow"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"3.Читаете ли вы книги?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Да",'callback_data'=>"naqa"],['text'=>"Нет",'callback_data'=>"naqas"]],
]
       ])
  ]);
}
if($data=="taq"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"2.Siz qancha vaqt uxlaysiz?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"6 soat",'callback_data'=>"dawa"],['text'=>"12 soat",'callback_data'=>"daw"]],
]
       ])
  ]);
}
if($data=="taqw"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"2.Siz qancha vaqt uxlaysiz?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"6 soat",'callback_data'=>"dawa"],['text'=>"12 soat",'callback_data'=>"daw"]],
]
       ])
  ]);
}
if($data=="dawa"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"3.Kitob oqiysizmi?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Ha",'callback_data'=>"nasa"],['text'=>"Yoq",'callback_data'=>"nas"]],
]
       ])
  ]);
}
if($data=="daw"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"3.Kitob oqiysizmi?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Ha",'callback_data'=>"nasa"],['text'=>"Yoq",'callback_data'=>"nas"]],
]
       ])
  ]);
}
if($data=="qu"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"1. Кто здесь является лишним?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Лев",'callback_data'=>"lev"],['text'=>"Тигр",'callback_data'=>"tigr"]],
[['text'=>"Гепард",'callback_data'=>"gepard"],['text'=>"Гиена",'callback_data'=>"giena"]],
]
       ])
  ]);
}
if($data=="leva"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
B  G  Е  J  i?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"ak"],['text'=>"M",'callback_data'=>"ma"],['text'=>"L",'callback_data'=>"al"]],
]
       ])
  ]);
}
if($data=="gienaa"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
B  G  Е  J  i?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"ak"],['text'=>"M",'callback_data'=>"ma"],['text'=>"L",'callback_data'=>"al"]],
]
       ])
  ]);
}
if($data=="geparda"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
B  G  Е  J  i?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"ak"],['text'=>"M",'callback_data'=>"ma"],['text'=>"L",'callback_data'=>"al"]],
]
       ])
  ]);
}
if($data=="tigar"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
B  G  Е  J  i?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"k"],['text'=>"M",'callback_data'=>"m"],['text'=>"L",'callback_data'=>"l"]],
]
       ])
  ]);
}
if($data=="lev"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
Б  Г  Е  Ж  И  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"k"],['text'=>"M",'callback_data'=>"m"],['text'=>"Л",'callback_data'=>"l"]],
]
       ])
  ]);
}
if($data=="tigr"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
Б  Г  Е  Ж  И  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"k"],['text'=>"M",'callback_data'=>"m"],['text'=>"Л",'callback_data'=>"l"]],
]
       ])
  ]);
}
if($data=="gepard"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
Б  Г  Е  Ж  И  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"k"],['text'=>"M",'callback_data'=>"m"],['text'=>"Л",'callback_data'=>"l"]],
]
       ])
  ]);
}
if($data=="giena"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
Б  Г  Е  Ж  И  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"K",'callback_data'=>"k"],['text'=>"M",'callback_data'=>"m"],['text'=>"Л",'callback_data'=>"l"]],
]
       ])
  ]);
}
if($data=="m"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21"],['text'=>"22",'callback_data'=>"22"],['text'=>"23",'callback_data'=>"23"]],
]
       ])
  ]);
}
if($data=="ma"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21a"],['text'=>"22",'callback_data'=>"22a"],['text'=>"23",'callback_data'=>"23a"]],
]
       ])
  ]);
}
if($data=="al"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21a"],['text'=>"22",'callback_data'=>"22a"],['text'=>"23",'callback_data'=>"23a"]],
]
       ])
  ]);
}
if($data=="ak"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Tartibni davom eting.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21a"],['text'=>"22",'callback_data'=>"22a"],['text'=>"23",'callback_data'=>"23a"]],
]
       ])
  ]);
}
if($data=="l"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21"],['text'=>"22",'callback_data'=>"22"],['text'=>"23",'callback_data'=>"23"]],
]
       ])
  ]);
}
if($data=="k"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Продолжите последовательность.
12 17  15  20  18  ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"21",'callback_data'=>"21"],['text'=>"22",'callback_data'=>"22"],['text'=>"23",'callback_data'=>"23"]],
]
       ])
  ]);
}
if($data=="21a"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Keyingi belgiga qo'shish kerakli rasmni tanlang.!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zz"],['text'=>"▲",'callback_data'=>"mm"],['text'=>"▽",'callback_data'=>"ll"]],
]
       ])
  ]);
}
if($data=="22a"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Keyingi belgiga qo'shish kerakli rasmni tanlang.!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zz"],['text'=>"▲",'callback_data'=>"mm"],['text'=>"▽",'callback_data'=>"ll"]],
]
       ])
  ]);
}
if($data=="23a"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Keyingi belgiga qo'shish kerakli rasmni tanlang.!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zz"],['text'=>"▲",'callback_data'=>"mm"],['text'=>"▽",'callback_data'=>"ll"]],
]
       ])
  ]);
}
if($data=="21"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Выберите рисунок , который необходимо добавить в следующем знаке!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zza"],['text'=>"▲",'callback_data'=>"mma"],['text'=>"▽",'callback_data'=>"lla"]],
]
       ])
  ]);
}
if($data=="22"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Выберите рисунок , который необходимо добавить в следующем знаке!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zza"],['text'=>"▲",'callback_data'=>"mma"],['text'=>"▽",'callback_data'=>"lla"]],
]
       ])
  ]);
}
if($data=="23"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Выберите рисунок , который необходимо добавить в следующем знаке!
◀▲▶?

",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"▶",'callback_data'=>"zza"],['text'=>"▲",'callback_data'=>"mma"],['text'=>"▽",'callback_data'=>"ll"]],
]
       ])
  ]);
}
if($data=="mm"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Какие две буквы должны идти дальше?
П   М   Й  Ж  ?
Е   Ж   И  К   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"ДМ",'callback_data'=>"dm"],['text'=>"ЕН",'callback_data'=>"eh"],['text'=>"ГН",'callback_data'=>"gh"]],
]
       ])
  ]);
}
if($data=="ll"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Какие две буквы должны идти дальше?
П   М   Й  Ж  ?
Е   Ж   И  К   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"ДМ",'callback_data'=>"dm"],['text'=>"ЕН",'callback_data'=>"eh"],['text'=>"ГН",'callback_data'=>"gh"]],
]
       ])
  ]);
}
if($data=="zza"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Qanday ikkita harf kerak?
P.   M   Y  J   ?
E   J     i    K   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"DМ",'callback_data'=>"dma"],['text'=>"ЕН",'callback_data'=>"eha"],['text'=>"GН",'callback_data'=>"gha"]],
]
       ])
  ]);
}
if($data=="mma"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Qanday ikkita harf kerak?
P.   M   Y  J   ?
E   J     i    K   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"DM",'callback_data'=>"dma"],['text'=>"ЕН",'callback_data'=>"eha"],['text'=>"GН",'callback_data'=>"gha"]],
]
       ])
  ]);
}
if($data=="lla"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Qanday ikkita harf kerak?
P.   M   Y  J   ?
E   J     i    K   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"DM",'callback_data'=>"dma"],['text'=>"ЕН",'callback_data'=>"eha"],['text'=>"GН",'callback_data'=>"gha"]],
]
       ])
  ]);
}
if($data=="zz"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Какие две буквы должны идти дальше
П   М   Й  Ж  ?
Е   Ж   И  К   ?",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"ДМ",'callback_data'=>"dm"],['text'=>"ЕН",'callback_data'=>"eh"],['text'=>"ГН",'callback_data'=>"gh"]],
]
       ])
  ]);
}
$input = array("25","83","41","82","62","52","95","23","77","27","32","75","36","11","41","97","99","100","53","29","88","37","64","90","72","33","81","7","60","62","71","23","93","95","71","98","31");
$rand=rand(0,7);
$soz="$input[$rand]";
if($data=="gh"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Ваш IQ равен *$soz*
Спасибо что прошли тест!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Пройти еще раз",'callback_data'=>"qu"],['text'=>"Mеню",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="eh"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Ваш IQ равен *$soz*
Спасибо что прошли тест!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Пройти еще раз",'callback_data'=>"qu"],['text'=>"Mеню",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="nas"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Siz jillikingiz  *$soz* teng😁",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Bowqattan oting",'callback_data'=>"daun"],['text'=>"Menu",'callback_data'=>"uzb"]],
]
       ])
  ]);
}
if($data=="nasa"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Siz jillikingiz  *$soz* teng😁",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Bowqattan oting",'callback_data'=>"daun"],['text'=>"Menu",'callback_data'=>"uzb"]],
]
       ])
  ]);
}
if($data=="naqa"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Ваш тупизм равен *$soz*
Спасибо что прошли тест!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Пройти еще раз",'callback_data'=>"dau"],['text'=>"Mеню",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="naqas"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Ваш тупизм равен *$soz*
Спасибо что прошли тест!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Пройти еще раз",'callback_data'=>"dau"],['text'=>"Mеню",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="dm"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"Ваш IQ равен *$soz*
Спасибо что прошли тест!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Пройти еще раз",'callback_data'=>"qu"],['text'=>"Mеню",'callback_data'=>"rus"]],
]
       ])
  ]);
}
if($data=="gha"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"IQ sizning *$soz*
Sinovni olganingiz uchun tashakkur.!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Qaytadan o'tish",'callback_data'=>"quzb"],['text'=>"Mеню",'callback_data'=>"uzb"]],
]
       ])
  ]);
}
if($data=="dma"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"IQ sizning *$soz*
Sinovni olganingiz uchun tashakkur.!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Qaytadan o'tish",'callback_data'=>"quzb"],['text'=>"Menu",'callback_data'=>"uzb"]],
]
       ])
  ]);
}
if($data=="eha"){
   bot('editMessageText',[
    'message_id'=>$message_id2,
    'chat_id'=>$ccid,
    'text'=>"IQ sizning *$soz*
Sinovni olganingiz uchun tashakkur.!",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
       [['text'=>"Qaytadan o'tish",'callback_data'=>"quzb"],['text'=>"Menu",'callback_data'=>"uzb"]],
]
       ])
  ]);
}
if ($update && !in_array($chat_id, $u)) {
    file_put_contents("memb.txt", $chat_id."\n",FILE_APPEND);
  }
#                   Списках                   #
if ($text == "/admin" and $chat_id == $admin ) {
    bot('sendMessage',[
        'chat_id'=>$chat_id,
      'text'=>"Раздел админов ",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>'Оправить смс всем','callback_data'=>'ce']],
[['text'=>'Статистика','callback_data'=>'co']],
            ]
            ])
        ]);
}
if($data == 'off'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
      'text'=>"лол кек чебурек",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>'Рассылка','callback_data'=>'ce']],
[['text'=>'Статистика','callback_data'=>'co']],
            ]
            ])
]);
file_put_contents('usr.txt', '');
}
#                   Рассылка                  #
if($data == "co" and $update->callback_query->message->chat->id == $admin ){ 
    bot('answercallbackquery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>"
        Количество подписчиков бота? :- [ $c ] .
        ",
        'show_alert'=>true,
]);
}
//Менюха
//

#           лол кек чебурек              #
if($data == "ce" and $update->callback_query->message->chat->id == $admin){ 
    file_put_contents("usr.txt","yas");
    bot('EditMessageText',[
    'chat_id'=>$update->callback_query->message->chat->id,
    'message_id'=>$update->callback_query->message->message_id,
    'text'=>"Всего  $c Участиков",
    'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>'отмена•','callback_data'=>'off']]
        ]
    ])
    ]);
}
if($text and $modxe == "yas" and $chat_id == $admin ){
    for ($i=0; $i < count($u); $i++) { 
        bot('sendMessage',[
          'chat_id'=>$u[$i],
          'text'=>"$text",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,

]);
    file_put_contents("usr.txt","no");

} 
}